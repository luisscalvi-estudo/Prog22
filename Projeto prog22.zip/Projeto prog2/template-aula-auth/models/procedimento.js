"use strict";

module.exports = (sequelize, DataTypes) => {
    const Procedimento = sequelize.define(
        "Procedimento",
        {
            id: {
                type: DataTypes.INTEGER,
                primaryKey: true,
                autoIncrement: true
            },
            nome: DataTypes.STRING,
            valor: DataTypes.DECIMAL(10, 2),
            duracao_minutos: DataTypes.INTEGER
        },
        {
            tableName: "procedimentos",
            timestamps: false,
        }
    );

    Procedimento.associate = function (models) {
        Procedimento.hasMany(models.Agendamento, {
            foreignKey: "procedimento_id"
        });
    };

    return Procedimento;
};
