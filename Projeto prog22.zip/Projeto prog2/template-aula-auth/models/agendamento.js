"use strict";

module.exports = (sequelize, DataTypes) => {
    const Agendamento = sequelize.define(
        "Agendamento",
        {
            id: {
                type: DataTypes.INTEGER,
                primaryKey: true,
                autoIncrement: true,
            },
            paciente_id: DataTypes.INTEGER,
            procedimento_id: DataTypes.INTEGER,
            usuario_id: DataTypes.INTEGER,
            data_hora: DataTypes.DATE,
            status: DataTypes.STRING,
            observacoes: DataTypes.TEXT,
        },
        {
            tableName: "agendamentos",
            timestamps: false,
        }
    );

  Agendamento.associate = function (models) {
    Agendamento.belongsTo(models.Paciente, {
        foreignKey: "paciente_id",
    });

    Agendamento.belongsTo(models.Procedimento, {
        foreignKey: "procedimento_id",
    });

    Agendamento.belongsTo(models.Usuario, {
        foreignKey: "usuario_id",
    });
};
    return Agendamento;
};
