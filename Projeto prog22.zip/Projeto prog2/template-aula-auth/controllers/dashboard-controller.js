const express = require("express");
const router = express.Router();
const DashboardService = require("../services/dashboard-service");

router.get("/", async (req, res) => {
    try {
        const data = await DashboardService.getDashboardInfo();
        return res.status(200).json(data);
    } catch (error) {
        console.error("Erro no Dashboard:", error);
        return res.status(500).json({ error: "Erro ao carregar Dashboard" });
    }
});

module.exports = router;