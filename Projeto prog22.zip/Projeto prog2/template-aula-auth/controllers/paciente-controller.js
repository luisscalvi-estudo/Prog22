const express = require("express");
const pacienteService = require("../services/paciente-service");
const authService = require("../services/auth-service");

const router = express.Router();

// GET /pacientes
router.get(
	"/",
	...authService.requirePermissao("VIZUALIZAR_PACIENTE"),
	pacienteService.retornaTodos,
);

// GET /pacientes/:id
router.get(
	"/:id",
	...authService.requirePermissao("VIZUALIZAR_PACIENTE"),
	pacienteService.retornaPorId,
);

// POST /pacientes
router.post(
	"/",
	authService.requireJWTAuth,
	pacienteService.cria,
);

// PUT /pacientes/:id
router.put(
	"/:id",
	authService.requireJWTAuth,
	pacienteService.atualiza,
);

// DELETE /pacientes/:id
router.delete(
	"/:id",
	authService.requireJWTAuth,
	pacienteService.deleta,
);


module.exports = router;
