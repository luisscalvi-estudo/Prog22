const express = require("express");
const agService = require("../services/agendamento-service");
const authService = require("../services/auth-service");

const router = express.Router();

// GET /agendamentos
router.get(
	"/",
	authService.requireJWTAuth,
	agService.retornaTodos,
);

// GET /agendamentos/:id
router.get(
	"/:id",
	authService.requireJWTAuth,
	agService.retornaPorId,
);

// POST /agendamentos
router.post("/", authService.requireJWTAuth, agService.cria);

// PUT /agendamentos/:id
router.put("/:id", authService.requireJWTAuth, agService.atualiza);

// DELETE /agendamentos/:id
router.delete("/:id", authService.requireJWTAuth, agService.deleta);

module.exports = router;
