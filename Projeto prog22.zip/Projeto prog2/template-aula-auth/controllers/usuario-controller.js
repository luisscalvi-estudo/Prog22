const express = require("express");
const usuarioService = require("../services/usuario-service");

const usuarioRouter = express.Router();

// POST /usuario - Criar novo usuário
usuarioRouter.post("/", authService.requireJWTAuth,usuarioService.criaUsuario);

// GET /usuario/todos - Retornar todos os usuários
usuarioRouter.get("/todos", authService.requireJWTAuth,usuarioService.retornaTodosUsuarios);

// GET /usuario/:id - Retornar usuário por ID
usuarioRouter.get("/:id", authService.requireJWTAuth,usuarioService.retornaUsuarioPorId);

// GET /usuario/:id/permissoes - Retornar usuário com permissões
usuarioRouter.get("/:id/permissoes", authService.requireJWTAuth,usuarioService.retornaUsuarioComPermissoes);

// PUT /usuario/:id - Atualizar usuário
usuarioRouter.put("/:id", authService.requireJWTAuth,usuarioService.atualizaUsuario);

// DELETE /usuario/:id - Deletar usuário
usuarioRouter.delete("/:id", authService.requireJWTAuth,usuarioService.deletaUsuario);

module.exports = usuarioRouter;
