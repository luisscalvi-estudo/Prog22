const express = require("express");
const procService = require("../services/procedimento-service");
const authService = require("../services/auth-service");

const router = express.Router();

// GET /procedimentos
router.get(
	"/",
	...authService.requirePermissao("VIZUALIZAR_PROCEDIMENTO"),
	procService.retornaTodos,
);

// GET /procedimentos/:id
router.get(
	"/:id",
	...authService.requirePermissao("VIZUALIZAR_PROCEDIMENTO"),
	procService.retornaPorId,
);

// POST /procedimentos
router.post("/", authService.requireJWTAuth, procService.cria);

// PUT /procedimentos/:id
router.put("/:id", authService.requireJWTAuth, procService.atualiza);

// DELETE /procedimentos/:id
router.delete("/:id", authService.requireJWTAuth, procService.deleta);

module.exports = router;
