const express = require("express");
const permissaoService = require("../services/permissao-service");

const permissaoRouter = express.Router();

// POST /permissao - Criar nova permissão
permissaoRouter.post("/", authService.requireJWTAuth,permissaoService.criaPermissao);

// GET /permissao/todos - Retornar todas as permissões
permissaoRouter.get("/todos", authService.requireJWTAuth,permissaoService.retornaTodasPermissoes);

// GET /permissao/:id - Retornar permissão por ID
permissaoRouter.get("/:id", authService.requireJWTAuth,permissaoService.retornaPermissaoPorId);

// PUT /permissao/:id - Atualizar permissão
permissaoRouter.put("/:id", authService.requireJWTAuth,permissaoService.atualizaPermissao);

// DELETE /permissao/:id - Deletar permissão
permissaoRouter.delete("/:id", authService.requireJWTAuth,permissaoService.deletaPermissao);

module.exports = permissaoRouter;
