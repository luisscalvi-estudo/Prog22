const passport = require("passport");
const LocalStrategy = require("passport-local").Strategy;
const JwtStrategy = require("passport-jwt").Strategy;
const ExtractJwt = require("passport-jwt").ExtractJwt;
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const model = require("../models");

// ======================================================
//  CONFIGURAR LOCAL STRATEGY (login com email + senha)
// ======================================================
const configureLocalStrategy = () => {
    passport.use(
        new LocalStrategy(
            {
                usernameField: "email",
                passwordField: "senha",
            },
            async (email, senha, done) => {
                try {
                    console.log("🔍 Tentando autenticar:", email);

                    const user = await model.Usuario.findOne({ where: { email } });
                    if (!user) {
                        console.log("❌ Usuário não encontrado");
                        return done(null, false);
                    }

                    const passwordMatch = await bcrypt.compare(senha, user.senha);
                    if (!passwordMatch) {
                        console.log("❌ Senha incorreta");
                        return done(null, false);
                    }

                    console.log("✅ Login OK — usuário:", user.id);
                    return done(null, user);

                } catch (error) {
                    console.error("Erro no LocalStrategy:", error);
                    return done(error);
                }
            }
        )
    );
};

// ======================================================
//  JWT STRATEGY (validação de token)
// ======================================================
const configureJwtStrategy = () => {
    passport.use(
        new JwtStrategy(
            {
                jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
                secretOrKey: "your-secret-key",
            },
            async (payload, done) => {
                try {
                    const user = await model.Usuario.findByPk(payload.id);
                    if (!user) return done(null, false);
                    return done(null, user);

                } catch (error) {
                    console.error("Erro no JwtStrategy:", error);
                    return done(error, false);
                }
            }
        )
    );
};

// ======================================================
// SERIALIZAÇÃO DO PASSAPORT
// ======================================================
const configureSerialization = () => {
    passport.serializeUser((user, done) => {
        done(null, { id: user.id, email: user.email });
    });

    passport.deserializeUser((data, done) => {
        done(null, data);
    });
};

// ======================================================
// CRIAÇÃO DE NOVO USUÁRIO
// ======================================================
const criarNovoUsuario = async ({ email, senha, nome }) => {
    await model.Usuario.create({
        email,
        nome,
        senha, 
    });

    return { email, nome };
};

// ======================================================
// GERAR TOKEN JWT
// ======================================================
const gerarToken = (usuario) => {
    return jwt.sign(
        {
            id: usuario.id,
            email: usuario.email,
        },
        "your-secret-key",
        { expiresIn: "1h" }
    );
};

const requireJWTAuth = passport.authenticate("jwt", { session: false });

// ======================================================
// PERMISSÕES
// ======================================================
const verificarPermissaoPorDescricao = async (email, descricaoPermissao) => {
    try {
        const permissao = await model.Permissao.findOne({
            where: { descricao: descricaoPermissao },
        });

        if (!permissao) return false;

        const usuarioPermissao = await model.UsuarioPermissao.findOne({
            where: {
                email,
                id_permissao: permissao.id,
            },
        });

        return usuarioPermissao !== null;

    } catch (error) {
        console.error("Erro ao verificar permissão:", error);
        return false;
    }
};

const obterPermissoesUsuario = async (email) => {
    try {
        const permissoes = await model.UsuarioPermissao.findAll({
            where: { email },
            include: [{ model: model.Permissao, as: "Permissao" }],
        });

        return permissoes.map((up) => up.Permissao);

    } catch (error) {
        console.error("Erro ao obter permissões do usuário:", error);
        return [];
    }
};

const verificarPermissaoMiddleware = (descricaoPermissao) => {
    return [
        requireJWTAuth,
        async (req, res, next) => {
            if (!req.user) {
                return res.status(401).json({ message: "Usuário não autenticado." });
            }

            const email = req.user.email;
            const temPermissao = await verificarPermissaoPorDescricao(email, descricaoPermissao);

            if (!temPermissao) {
                return res.status(403).json({
                    message: `Acesso negado. Permissão necessária: ${descricaoPermissao}`,
                });
            }

            next();
        },
    ];
};

// ======================================================
// EXPORTAR TODAS FUNÇÕES
// ======================================================
module.exports = {
    configureLocalStrategy,
    configureJwtStrategy,
    configureSerialization,
    criarNovoUsuario,
    gerarToken,
    requireJWTAuth,
    verificarPermissaoPorDescricao,
    obterPermissoesUsuario,
    verificarPermissaoMiddleware,
    requirePermissao: verificarPermissaoMiddleware,
};
