    const pacienteRepository = require("../repositories/paciente-repository");
    const db = require("../models"); // 🔥 IMPORTANTE para fazer query raw
    const { QueryTypes } = require("sequelize");

    const retornaTodos = async (req, res) => {
        try {
            const pacientes = await pacienteRepository.obterTodos();
            res.status(200).json({ pacientes });
        } catch (error) {
            console.error("Erro ao buscar pacientes:", error);
            res.sendStatus(500);
        }
    };

    const retornaPorId = async (req, res) => {
        try {
            const id = parseInt(req.params.id);
            const paciente = await pacienteRepository.obterPorId({ id });

            if (!paciente) {
                return res.status(404).json({ message: "Paciente não encontrado" });
            }

            res.status(200).json(paciente);
        } catch (error) {
            console.error(error);
            res.sendStatus(500);
        }
    };

    const cria = async (req, res) => {
        try {
            const { nome, cpf, telefone, email } = req.body;

            if (!nome || !cpf) {
                return res.status(400).json({ message: "Nome e CPF são obrigatórios." });
            }

            const novo = await pacienteRepository.criar({
                nome,
                cpf,
                telefone,
                email,
                criado_em: new Date()
            });

            res.status(201).json(novo);
        } catch (error) {
            console.error(error);
            res.sendStatus(500);
        }
    };

    const atualiza = async (req, res) => {
        try {
            const id = parseInt(req.params.id);
            const { nome, cpf, telefone, email } = req.body;

            const atualizado = await pacienteRepository.atualizar({
                id,
                nome,
                cpf,
                telefone,
                email
            });

            res.status(200).json(atualizado);
        } catch (error) {
            console.error(error);
            res.sendStatus(500);
        }
    };

    const deleta = async (req, res) => {
        try {
            const id = parseInt(req.params.id);
            await pacienteRepository.deletar({ id });

            res.status(200).json({ message: "Paciente removido" });
        } catch (error) {
            console.error(error);
            res.sendStatus(500);
        }
    };

    /* ============================================================
        NOVO MÉTODO: OBTÉM PACIENTES + ÚLTIMA CONSULTA
    ============================================================ */
    const obterTodosComUltimaConsulta = async (req, res) => {
        try {
            const resultado = await db.sequelize.query(
                `
                SELECT
                    p.id,
                    p.nome,
                    p.cpf,
                    p.telefone,
                    p.email,
                    (
                        SELECT MAX(a.data_hora)
                        FROM agendamentos a
                        WHERE a.paciente_id = p.id
                        AND a.status IN ('concluido', 'pago')
                    ) AS ultima_consulta
                FROM pacientes p
                ORDER BY p.nome;
                `,
                { type: QueryTypes.SELECT }
            );

            res.status(200).json({ pacientes: resultado });

        } catch (error) {
            console.error("Erro ao buscar pacientes com última consulta:", error);
            res.sendStatus(500);
        }
    };

    module.exports = {
        retornaTodos,
        retornaPorId,
        cria,
        atualiza,
        deleta,
        obterTodosComUltimaConsulta
    };
