const agRepo = require("../repositories/agendamento-repository");
const luxon = require('luxon'); 
const { DateTime } = luxon;

const retornaTodos = async (req, res) => {
	try {
		const { usuario_id } = req.query; // <-- PEGAR FILTRO DO FRONT

		let filtro = {};

		// Se vier ?usuario_id=123, aplica filtro
		// Se vier ?usuario_id=all, ignora
		if (usuario_id && usuario_id !== "all") {
			filtro.usuario_id = Number(usuario_id);
		}

		// Agora passa esse filtro pro repository
		const lista = await agRepo.obterTodos(filtro);

		res.status(200).json({ agendamentos: lista });
	} catch (error) {
		console.error("Erro ao buscar agendamentos:", error);
		res.sendStatus(500);
	}
};

const retornaPorId = async (req, res) => {
	try {
		const id = parseInt(req.params.id);
		const item = await agRepo.obterPorId({ id });

		if (!item) {
			return res.status(404).json({
				message: "Agendamento não encontrado.",
			});
		}

		res.status(200).json(item);
	} catch (error) {
		console.error(error);
		res.sendStatus(500);
	}
};

const cria = async (req, res) => {
    try {
        const { paciente_id, procedimento_id, data_hora, status, observacoes, usuario_id } = req.body;

        // ... (validações)

        // 1. Interpreta a string como hora local (America/Sao_Paulo, ou seja, UTC-3)
        const dataHoraLocal = DateTime.fromISO(data_hora, { zone: 'America/Sao_Paulo' });
        
        if (!dataHoraLocal.isValid) {
             return res.status(400).json({
                message: "Formato de data/hora inválido.",
            });
        }
        
        // 2. Converte para um objeto Date nativo. Isso mantém o instante de tempo (timestamp) correto.
        const dataHoraAjustada = dataHoraLocal.toJSDate(); 
        
        const novo = await agRepo.criar({
            paciente_id,
            procedimento_id,
            data_hora: dataHoraAjustada, // <-- USAR O OBJETO DATE NATIVO
            status: status || "PENDENTE",
            observacoes,
            usuario_id: usuario_id || null, 
        });

        res.status(201).json(novo);
    } catch (error) {
        console.error("Erro em cria:", error);
        res.sendStatus(500);
    }
};

// --- FUNÇÃO ATUALIZA (Edição) ---
const atualiza = async (req, res) => {
    try {
        const id = parseInt(req.params.id);
        const { paciente_id, procedimento_id, data_hora, status, observacoes, usuario_id } = req.body;
            
        let dataHoraAjustada = data_hora;

        if (data_hora) {
            const dataHoraLocal = DateTime.fromISO(data_hora, { zone: 'America/Sao_Paulo' });
            
            if (!dataHoraLocal.isValid) {
                 return res.status(400).json({
                    message: "Formato de data/hora inválido.",
                });
            }
            // Converte para um objeto Date nativo.
            dataHoraAjustada = dataHoraLocal.toJSDate(); 
        }

        const atualizado = await agRepo.atualizar({
            id,
            paciente_id,
            procedimento_id,
            data_hora: dataHoraAjustada, // <-- USAR O OBJETO DATE NATIVO
            status,
            observacoes,
            usuario_id: usuario_id || null, 
        });

        res.status(200).json(atualizado);
    } catch (error) {
        console.error("Erro em atualiza:", error);
        res.sendStatus(500);
    }
};

const deleta = async (req, res) => {
	try {
		const id = parseInt(req.params.id);
		await agRepo.deletar({ id });

		res.status(200).json({ message: "Agendamento removido." });
	} catch (error) {
		console.error(error);
		res.sendStatus(500);
	}
};

module.exports = {
	retornaTodos,
	retornaPorId,
	cria,
	atualiza,
	deleta,
};
