const usuarioRepository = require("../repositories/usuario-repository");
const bcrypt = require("bcrypt");

// ==================== LISTAR TODOS ====================
const retornaTodosUsuarios = async (req, res) => {
    try {
        const usuarios = await usuarioRepository.obterTodosUsuarios();
        res.status(200).json({ usuarios });
    } catch (error) {
        console.log("Erro ao buscar usuários:", error);
        res.sendStatus(500);
    }
};

// ==================== CRIAR ====================
// ==================== CRIAR (CORRIGIDO) ====================
const criaUsuario = async (req, res) => {
    // 1. Remova 'id' da desestruturação. Não esperamos o ID na criação.
    const { email, nome, senha } = req.body; 

    try {
        // 2. Ajuste a validação: Apenas email, nome e senha são obrigatórios.
        if (!email || !nome || !senha) { 
            return res.status(400).json({
                message: "Email, nome e senha são obrigatórios."
            });
        }

        const salt = await bcrypt.genSalt(10);
        const senhaHash = await bcrypt.hash(senha, salt);

        const usuario = await usuarioRepository.criarUsuario({
            email,
            nome,
            senha: senhaHash
        });

        res.status(201).json(usuario);
    } catch (error) {
        console.log("Erro ao criar usuário:", error);
        res.sendStatus(500);
    }
};

// ==================== ATUALIZAR ====================
const atualizaUsuario = async (req, res) => {
    const id = parseInt(req.params.id);
    const { nome, senha } = req.body;

    try {
        let senhaHash;

        if (senha) {
            const salt = await bcrypt.genSalt(10);
            senhaHash = await bcrypt.hash(senha, salt);
        }

        const usuarioAtualizado = await usuarioRepository.atualizarUsuario({
            id,
            nome,
            senha: senhaHash
        });

        if (usuarioAtualizado) {
            res.status(200).json(usuarioAtualizado);
        } else {
            res.status(404).json({ message: "Usuário não encontrado" });
        }
    } catch (error) {
        console.log("Erro ao atualizar usuário:", error);
        res.sendStatus(500);
    }
};

// ==================== DELETAR ====================
const deletaUsuario = async (req, res) => {
    try {
        const id = parseInt(req.params.id);

        const usuarioRemovido = await usuarioRepository.deletarUsuario({ id });

        if (usuarioRemovido) {
            res.status(200).json({
                message: "Usuário removido com sucesso.",
                usuario: usuarioRemovido
            });
        } else {
            res.status(404).json({ message: "Usuário não encontrado" });
        }
    } catch (error) {
        console.error("Erro ao deletar usuário:", error);
        res.status(500).json({ message: "Erro ao deletar usuário" });
    }
};

// ==================== BUSCAR POR ID ====================
const retornaUsuarioPorId = async (req, res) => {
    try {
        const id = parseInt(req.params.id);

        const usuario = await usuarioRepository.obterUsuarioPorId({ id });

        if (usuario) {
            res.status(200).json(usuario);
        } else {
            res.status(404).json({ message: "Usuário não encontrado." });
        }
    } catch (error) {
        console.log("Erro ao buscar usuário:", error);
        res.sendStatus(500);
    }
};

// ==================== USUÁRIO + PERMISSÕES ====================
const retornaUsuarioComPermissoes = async (req, res) => {
    try {
        const id = parseInt(req.params.id);

        const usuario = await usuarioRepository.obterUsuarioComPermissoes({ id });

        if (usuario) {
            res.status(200).json(usuario);
        } else {
            res.status(404).json({ message: "Usuário não encontrado." });
        }
    } catch (error) {
        console.log("Erro ao buscar usuário com permissões:", error);
        res.sendStatus(500);
    }
};

module.exports = {
    retornaTodosUsuarios,
    criaUsuario,
    atualizaUsuario,
    deletaUsuario,
    retornaUsuarioPorId,
    retornaUsuarioComPermissoes
};
