const model = require("../models");
const { Op } = require("sequelize");

/* ================= LISTAR COM FILTRO ================= */
const obterTodos = async (filtro = {}) => {
	return await model.Agendamento.findAll({
		where: filtro, // <-- Agora aceita filtro (ex.: usuario_id)
		include: [
			{
				model: model.Paciente,
			},
			{
				model: model.Procedimento,
			},
			{
				model: model.Usuario, 
				attributes: ["id", "nome"]
			}
		],
		order: [["data_hora", "ASC"]],
	});
};

/* ================= BUSCAR POR ID ================= */
const obterPorId = async (ag) => {
	return await model.Agendamento.findByPk(ag.id, {
		include: [
			model.Paciente,
			model.Procedimento,
			{
				model: model.Usuario,
				attributes: ["id", "nome"]
			}
		],
	});
};

/* ================= CRIAR ================= */
const criar = async (ag) => {
	return await model.Agendamento.create(ag);
};

/* ================= ATUALIZAR ================= */
const atualizar = async (ag) => {
	await model.Agendamento.update(ag, {
		where: { id: ag.id },
	});

	return await model.Agendamento.findByPk(ag.id, {
		include: [
			model.Paciente,
			model.Procedimento,
			{
				model: model.Usuario,
				attributes: ["id", "nome"]
			}
		],
	});
};

/* ================= DELETAR ================= */
const deletar = async (ag) => {
	await model.Agendamento.destroy({
		where: { id: ag.id }
	});
	return ag;
};

module.exports = {
	obterTodos,
	obterPorId,
	criar,
	atualizar,
	deletar,
};
