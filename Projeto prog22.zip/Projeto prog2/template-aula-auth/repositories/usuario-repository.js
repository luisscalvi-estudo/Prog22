const model = require("../models");

// ==================== LISTAR ====================
const obterTodosUsuarios = async () => {
    return await model.Usuario.findAll();
};

// ==================== BUSCAR POR ID ====================
const obterUsuarioPorId = async ({ id }) => {
    return await model.Usuario.findByPk(id);
};

// ==================== BUSCAR POR ID + PERMISSÕES ====================
const obterUsuarioComPermissoes = async ({ id }) => {
    return await model.Usuario.findByPk(id, {
        include: [model.Permissao] // se existir
    });
};

// ==================== CRIAR ====================
const criarUsuario = async (usuario) => {
    return await model.Usuario.create(usuario);
};

// ==================== ATUALIZAR ====================
const atualizarUsuario = async ({ id, nome, senha }) => {
    const dados = {};

    if (nome) dados.nome = nome;
    if (senha) dados.senha = senha;

    await model.Usuario.update(dados, {
        where: { id }
    });

    return await model.Usuario.findByPk(id);
};

// ==================== DELETAR ====================
const deletarUsuario = async ({ id }) => {
    const usuario = await model.Usuario.findByPk(id);

    if (!usuario) return null;

    await model.Usuario.destroy({ where: { id } });

    return usuario;
};

module.exports = {
    obterTodosUsuarios,
    obterUsuarioPorId,
    obterUsuarioComPermissoes,
    criarUsuario,
    atualizarUsuario,
    deletarUsuario
};
