const model = require("../models");
const { Op } = require("sequelize");
const moment = require("moment");

const obterResumoDashboard = async () => {
    const hoje = moment().startOf("day");
    const inicioMes = moment().startOf("month");

    // Total de pacientes
    const totalPacientes = await model.Paciente.count();

    // Consultas hoje
    const consultasHoje = await model.Agendamento.count({
        where: {
            data_hora: {
                [Op.between]: [hoje.toDate(), moment(hoje).endOf("day").toDate()]
            }
        }
    });

    // Procedimentos realizados no mês
    const procedimentosMes = await model.Agendamento.count({
        where: {
            data_hora: {
                [Op.between]: [inicioMes.toDate(), moment().endOf("month").toDate()]
            },
            status: "REALIZADO"
        }
    });

    // Faturamento do mês (somando preço do procedimento)
    const faturamentoMes = await model.Agendamento.findAll({
        where: {
            data_hora: {
                [Op.between]: [inicioMes.toDate(), moment().endOf("month").toDate()]
            },
            status: "REALIZADO"
        },
        include: [model.Procedimento]
    });

    const totalFaturamento = faturamentoMes.reduce(
        (acc, ag) => acc + (ag.Procedimento?.preco || 0),
        0
    );

    // Próximas consultas
    const proximasConsultas = await model.Agendamento.findAll({
        where: {
            data_hora: { [Op.gt]: moment().toDate() }
        },
        include: [model.Paciente],
        limit: 5,
        order: [["data_hora", "ASC"]]
    });

    // Consultas por mês (últimos 4 meses)
    const meses = [];
    for (let i = 3; i >= 0; i--) {
        const inicio = moment().subtract(i, "months").startOf("month");
        const fim = moment().subtract(i, "months").endOf("month");

        const qtd = await model.Agendamento.count({
            where: {
                data_hora: {
                    [Op.between]: [inicio.toDate(), fim.toDate()]
                }
            }
        });

        meses.push({
            mes: inicio.format("MMM").toUpperCase(),
            consultas: qtd
        });
    }

    return {
        totalPacientes,
        consultasHoje,
        procedimentosMes,
        faturamentoMes: totalFaturamento,
        proximasConsultas,
        consultasPorMes: meses
    };
};

module.exports = {
    obterResumoDashboard
};
