DROP TABLE IF EXISTS matricula;
DROP TABLE IF EXISTS aluno;
DROP TABLE IF EXISTS professor_ccr;
DROP TABLE IF EXISTS ccr;
DROP TABLE IF EXISTS curso;
DROP TABLE IF EXISTS professor;

-- #################################
-- 1. CRIAÇÃO DA TABELA PACIENTES
-- #################################
CREATE TABLE pacientes (
    id SERIAL PRIMARY KEY, -- PRIMARY KEY com auto-incremento (SERIAL é comum no PostgreSQL)
    nome VARCHAR(255) NOT NULL,
    telefone VARCHAR(15), -- Suficiente para armazenar (XX) XXXXX-XXXX sem máscara
    email VARCHAR(255) UNIQUE, -- UNIQUE para evitar duplicidade de e-mails
    cpf VARCHAR(14) UNIQUE, -- UNIQUE para CPF (pode ser formatado com máscara 999.999.999-99)
    criado_em TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

---

-- #################################
-- 2. CRIAÇÃO DA TABELA PROCEDIMENTOS
-- #################################
CREATE TABLE procedimentos (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    valor NUMERIC(10, 2) NOT NULL, -- NUMERIC para valores monetários (até 10 dígitos, 2 decimais)
    duracao_minutos INTEGER NOT NULL -- Armazena a duração em minutos
);

---

-- #################################
-- 3. CRIAÇÃO DA TABELA AGENDAMENTOS (Relacionamento entre Pacientes e Procedimentos)
-- #################################
CREATE TABLE agendamentos (
    id SERIAL PRIMARY KEY,
    
    -- Chave Estrangeira para a tabela pacientes
    paciente_id INTEGER NOT NULL,
    CONSTRAINT fk_paciente
        FOREIGN KEY (paciente_id)
        REFERENCES pacientes (id)
        ON DELETE RESTRICT, -- Restringe a exclusão de um paciente se houver agendamentos associados
    
    -- Chave Estrangeira para a tabela procedimentos
    procedimento_id INTEGER NOT NULL,
    CONSTRAINT fk_procedimento
        FOREIGN KEY (procedimento_id)
        REFERENCES procedimentos (id)
        ON DELETE RESTRICT,
);


create table permissao
(
  id bigint  NOT NULL,
  descricao varchar NOT NULL,
  PRIMARY KEY (id)
);

create table usuario
( 
  id SERIAL PRIMARY KEY
  email varchar NOT NULL,
  nome varchar NOT NULL,
  senha varchar NOT NULL,
);

create table usuario_permissao
(
  email varchar NOT NULL,
  id_permissao bigint NOT NULL,
  PRIMARY KEY (email, id_permissao),
  CONSTRAINT FK_usuario_permissao_usuario FOREIGN KEY (email) REFERENCES usuario (email),
  CONSTRAINT FK_usuario_permissao_permissao FOREIGN KEY (id_permissao) REFERENCES permissao (id)
);


INSERT INTO permissao (id, descricao) VALUES (1, 'VISUALIZAR_ALUNOS');
INSERT INTO permissao (id, descricao) VALUES (2, 'VISUALIZAR_CURSOS');
INSERT INTO permissao (id, descricao) VALUES (3, 'VISUALIZAR_MATRICULAS');
INSERT INTO permissao (id, descricao) VALUES (4, 'VISUALIZAR_PROFESSORES');
INSERT INTO permissao (id, descricao) VALUES (5, 'VISUALIZAR_CCRS');
INSERT INTO permissao (id, descricao) VALUES (6, 'VISUALIZAR_PROFESSOR_CCRS');

INSERT INTO usuario (email, nome, senha) VALUES ('admin@uffs.edu.br', 'Administrador', 'admin');
INSERT INTO usuario (email, nome, senha) VALUES ('user@uffs.edu.br', 'Usuário', 'user');

INSERT INTO usuario_permissao (email, id_permissao) VALUES ('admin@uffs.edu.br', 1);
INSERT INTO usuario_permissao (email, id_permissao) VALUES ('admin@uffs.edu.br', 2);
INSERT INTO usuario_permissao (email, id_permissao) VALUES ('admin@uffs.edu.br', 3);
INSERT INTO usuario_permissao (email, id_permissao) VALUES ('admin@uffs.edu.br', 4);
INSERT INTO usuario_permissao (email, id_permissao) VALUES ('admin@uffs.edu.br', 5);
INSERT INTO usuario_permissao (email, id_permissao) VALUES ('admin@uffs.edu.br', 6);


 INSERT INTO pacientes (nome, telefone, email, cpf) VALUES 
('Ana Souza', '11987654321', 'ana@exemplo.com', '12345678901');

INSERT INTO procedimentos (nome, valor, duracao_minutos) VALUES 
('Consulta Inicial', 150.00, 45),
('Limpeza Dental', 200.00, 60);

-- Agendar Limpeza Dental para Ana Souza
INSERT INTO agendamentos (paciente_id, procedimento_id, data_hora, status) VALUES 
(1, 2, '2025-12-15 10:00:00-03', 'Agendado');