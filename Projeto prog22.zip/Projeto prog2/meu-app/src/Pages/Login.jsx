import { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "../CSS/Login.css";

export default function Login({ setIsLoggedIn }) {
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [message, setMessage] = useState("");

  const navigate = useNavigate();

  async function enviaLogin(e) {
    e.preventDefault();
    setMessage("");

    try {
      const response = await axios.post("http://localhost:3002/login", {
        email: email,
        senha: senha,
      });

      if (response.status === 200 && response.data.token) {
        localStorage.setItem("token", response.data.token);

        // ✅ AGORA O APP SABE QUE VOCÊ ESTÁ LOGADO
        setIsLoggedIn(true);

        navigate("/dashboard");
      }
    } catch (error) {
      console.error("Erro no login:", error);
      setMessage("Email ou senha inválidos!");
    }
  }

  return (
    <div className="login-container">
      <div className="login-card">
        <h1>Log In</h1>

        <form onSubmit={enviaLogin}>
          <label>Email</label>
          <input
            type="email"
            placeholder="seu@email.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />

          <label>Senha</label>

          <div className="password-box">
            <input
              type={showPassword ? "text" : "password"}
              value={senha}
              onChange={(e) => setSenha(e.target.value)}
              required
            />

            <span
              className="eye"
              onClick={() => setShowPassword(!showPassword)}
            >
              👁
            </span>
          </div>

          <button type="submit" className="login-btn">
            LOGIN
          </button>

          <p className="register">
            Não possui uma conta? <span>Cadastre-se</span>
          </p>

          {message && <p className="error">{message}</p>}
        </form>
      </div>
    </div>
  );
}
