// ======= IMPORTS =============================================================
import { useState, useEffect } from "react";
import axios from "axios";
import "../CSS/Agenda.css";

import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import interactionPlugin from "@fullcalendar/interaction";

import { useNavigate } from "react-router-dom";

import {
  Box,
  Avatar,
  IconButton,
  Modal,
  Typography,
  Divider,
  Button,
  TextField,
  MenuItem,
} from "@mui/material";

import {
  Home as HomeIcon,
  EventNote as CalendarIcon,
  People as PeopleIcon,
  Settings as SettingsIcon,
  Logout as LogoutIcon,
  Vaccines as MedicineIcon,
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
} from "@mui/icons-material";

// ============================================================================
// ============================= COMPONENTE ===================================
// ============================================================================

export default function Agenda({ setIsLoggedIn }) {
  const navigate = useNavigate();
  const API_URL = "http://localhost:3002";

  // ==== STATES ORIGINAIS ====================================================
  const [allEvents, setAllEvents] = useState([]);
  const [dailyEvents, setDailyEvents] = useState([]);

  const [pacientes, setPacientes] = useState([]);
  const [procedimentos, setProcedimentos] = useState([]);
  const [dentistas, setDentistas] = useState([]);

  const [openModal, setOpenModal] = useState(false);
  const [selectedDate, setSelectedDate] = useState("");

  const [editingAgendamentoId, setEditingAgendamentoId] = useState(null);
  const [openNovoModal, setOpenNovoModal] = useState(false);

  const [formAgendamento, setFormAgendamento] = useState({
    paciente_id: "",
    procedimento_id: "",
    usuario_id: "",
    data: "",
    hora: "",
    status: "agendado",
    observacoes: "",
  });

  const userPermissions = ["VIZUALIZAR_AGENDA", "VIZUALIZAR_PACIENTE", "CRIAR_AGENDA", /* ... */ ]; 

  const temPermissao = (permissao) => {
    // Implemente a lógica real de busca. Se as permissões estiverem no state, use o state.
    // Exemplo Simples (Ajuste conforme seu estado de permissões):
    return userPermissions.includes(permissao); 
};

  // ===== 🆕 STATE DO FILTRO DE DENTISTA ====================================
  // valor padrão: 0 = todos os dentistas
  const [dentistaFiltro, setDentistaFiltro] = useState(0);

  const getToken = () => localStorage.getItem("token");

  function handleLogout() {
    localStorage.removeItem("token");
    setIsLoggedIn(false);
    navigate("/");
  }

  // ========================================================================
  // ============================ FETCH EVENTS ==============================
  // ========================================================================

  const fetchEvents = async () => {
    try {
      const token = getToken();
      if (!token) return navigate("/");

      const res = await axios.get(`${API_URL}/agendamentos`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      const eventosTransformados = res.data.agendamentos.map((item) => {
        const dateObj = new Date(item.data_hora);
        const horario = dateObj.toLocaleTimeString("pt-BR", {
          hour: "2-digit",
          minute: "2-digit",
        });

        return {
          id: item.id,
          title: `${item.Procedimento?.nome || "Procedimento"}\n${horario}`,
          date: item.data_hora.split("T")[0],
          color: "#5BA3C3",
          raw: item,
        };
      });

      setAllEvents(eventosTransformados);
    } catch (error) {
      console.error("Erro ao carregar agendamentos:", error);
    }
  };

  const fetchDentistas = async () => {
    try {
      const token = getToken();
      const res = await axios.get(`${API_URL}/usuario/todos`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      setDentistas(res.data.usuarios);
    } catch (error) {
      console.error("Erro ao carregar dentistas:", error);
    }
  };

  const fetchPacientes = async () => {
    try {
      const token = getToken();
      const res = await axios.get(`${API_URL}/pacientes`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      setPacientes(res.data.pacientes);
    } catch (error) {
      console.error("Erro pacientes", error);
    }
  };

  const fetchProcedimentos = async () => {
    try {
      const token = getToken();
      const res = await axios.get(`${API_URL}/procedimentos`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      setProcedimentos(res.data.procedimentos);
    } catch (error) {
      console.error("Erro procedimentos", error);
    }
  };

  useEffect(() => {
    fetchEvents();
    fetchDentistas();
    fetchPacientes();
    fetchProcedimentos();
  }, []);

  // ========================================================================
  // ======================= FILTRO DE DENTISTAS ============================
  // ========================================================================

  const eventosFiltrados = dentistaFiltro === 0
    ? allEvents
    : allEvents.filter(ev => ev.raw.usuario_id === dentistaFiltro);

  // ========================================================================
  // ========================= MANIPULAÇÃO FORM =============================
  // ========================================================================

  const handleOpenNovoModal = (date = "", raw = null) => {
    setOpenModal(false);

    if (raw) {
      const dt = new Date(raw.data_hora);

      setEditingAgendamentoId(raw.id);
      setFormAgendamento({
        paciente_id: raw.paciente_id,
        procedimento_id: raw.procedimento_id,
        usuario_id: raw.usuario_id,
        data: dt.toISOString().split("T")[0],
        hora: dt.toTimeString().slice(0, 5),
        status: raw.status,
        observacoes: raw.observacoes,
      });
    } else {
      setEditingAgendamentoId(null);
      setFormAgendamento({
        paciente_id: "",
        procedimento_id: "",
        usuario_id: "",
        data,
        hora: "",
        status: "agendado",
        observacoes: "",
      });
    }

    setOpenNovoModal(true);
  };

  const handleChangeNovo = (e) => {
    setFormAgendamento({
      ...formAgendamento,
      [e.target.name]: e.target.value,
    });
  };

  const handleNovo = async () => {
    try {
      const token = getToken();

      await axios.post(
        `${API_URL}/agendamentos`,
        {
          paciente_id: Number(formAgendamento.paciente_id),
          procedimento_id: Number(formAgendamento.procedimento_id),
          usuario_id: Number(formAgendamento.usuario_id),
          data_hora: `${formAgendamento.data}T${formAgendamento.hora}:00`,
          status: formAgendamento.status,
          observacoes: formAgendamento.observacoes,
        },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      alert("Agendamento criado!");
      setOpenNovoModal(false);
      fetchEvents();
    } catch (err) {
      console.error(err);
      alert("Erro ao criar");
    }
  };

  const handleUpdate = async () => {
    try {
      const token = getToken();

      await axios.put(
        `${API_URL}/agendamentos/${editingAgendamentoId}`,
        {
          paciente_id: Number(formAgendamento.paciente_id),
          procedimento_id: Number(formAgendamento.procedimento_id),
          usuario_id: Number(formAgendamento.usuario_id),
          data_hora: `${formAgendamento.data}T${formAgendamento.hora}:00`,
          status: formAgendamento.status,
          observacoes: formAgendamento.observacoes,
        },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      alert("Atualizado!");
      setOpenNovoModal(false);
      fetchEvents();
    } catch (err) {
      console.error(err);
      alert("Erro ao atualizar");
    }
  };

  const handleDeleteAgendamento = async (id) => {
    if (!window.confirm("Deseja excluir?")) return;

    try {
      const token = getToken();
      await axios.delete(`${API_URL}/agendamentos/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      alert("Excluído!");
      fetchEvents();
    } catch (err) {
      alert("Erro ao excluir");
    }
  };

  const handleDateClick = (info) => {
    setSelectedDate(info.dateStr);

    const filtered = eventosFiltrados.filter(
      (ev) => ev.date === info.dateStr
    );

    setDailyEvents(filtered);
    setOpenModal(true);
  };

  const getDentistaNome = (id) =>
    dentistas.find((d) => d.id === id)?.nome || "N/A";

  // ==========================================================================
  // ============================= RENDER =====================================
  // ==========================================================================

return (
    <Box className="dashboard-layout" sx={{ display: 'flex', height: '100vh', overflow: 'hidden' }}> {/* Garante que o layout ocupe a tela toda */}
      
      {/* SIDEBAR */}
      <Box className="sidebar">
        <Box className="sidebar-logo">
          <Avatar sx={{ width: 48, height: 48, background: "#fff", color: "#5BA3C3" }}> M </Avatar>
        </Box>

        <Box className="sidebar-nav">
          <IconButton className="nav-icon" onClick={() => navigate("/dashboard")}> <HomeIcon /> </IconButton>
          <IconButton className="nav-icon active"> <CalendarIcon /> </IconButton>
          <IconButton className="nav-icon" onClick={() => navigate("/pacientes")}> <PeopleIcon /> </IconButton>
          <IconButton className="nav-icon" onClick={() => navigate("/procedimentos")}> <MedicineIcon /> </IconButton>
          <IconButton className="nav-icon"> <SettingsIcon /> </IconButton>

          <div className="sidebar-logout">
            <IconButton className="nav-icon logout-btn" onClick={handleLogout}> <LogoutIcon /> </IconButton>
          </div>
        </Box>
      </Box>

      {/* ====================== CONTEÚDO PRINCIPAL =========================== */}
      <Box className="main-content" sx={{ 
          flex: 1, 
          display: "flex", 
          flexDirection: "column", 
          height: "100vh", 
          overflow: "hidden" 
      }}>

        {/* ===================== FILTRO DE DENTISTA (CABEÇALHO) ========================= */}
        {/* Este Box vai ocupar a altura natural dele */}
        <Box sx={{ p: 2, pb:0.1 ,display: "flex", alignItems: "center", gap: 2, flexShrink: 0 }}>
          <TextField
            select
            label="Filtrar por dentista"
            value={dentistaFiltro}
            onChange={(e) => setDentistaFiltro(Number(e.target.value))}
            sx={{ width: 260 }}
          >
            <MenuItem value={0}>Todos os dentistas</MenuItem>
            {dentistas.map((d) => (
              <MenuItem key={d.id} value={d.id}>{d.nome}</MenuItem>
            ))}
          </TextField>

          <Button
            variant="contained"
            startIcon={<AddIcon />}
            onClick={() => handleOpenNovoModal()}
            sx={{ background: "#5BA3C3" }}
          >
            Novo Agendamento
          </Button>
        </Box>

        {/* ================= CALENDÁRIO ================= */}
        {/* ALTERAÇÃO 2: Envolva o FullCalendar num Box com "flex: 1" e "overflow: auto"
            Isso diz: "Ocupe TODO o espaço restante da tela abaixo do filtro"
        */}
        <Box sx={{ flex: 1, overflow: "hidden", p: 2, pt: 0 }}> 
          <FullCalendar
            plugins={[dayGridPlugin, interactionPlugin]}
            initialView="dayGridMonth"
            height="100%" 
            locale="pt-br"
            events={eventosFiltrados}
            dateClick={handleDateClick}
            headerToolbar={{
              left: "prev,next title",
              center: "",
              right: "",
            }}
          />
        </Box>
        
      </Box>

      {/* =====================================================================
          MODAL CONSULTAS DO DIA
      ===================================================================== */}
      <Modal open={openModal} onClose={() => setOpenModal(false)}>
        <Box sx={{
          position: "absolute", top: "50%", left: "50%",
          transform: "translate(-50%, -50%)",
          width: 480, bgcolor: "#fff", p: 3, borderRadius: 2
        }}>
          <Typography variant="h5" fontWeight={600}>
            Consultas em {selectedDate}
          </Typography>

          <Divider sx={{ my: 2 }} />

          {dailyEvents.length === 0 ? (
            <Typography>Nenhuma consulta neste dia.</Typography>
          ) : (
            dailyEvents.map((ev) => {
              const h = new Date(ev.raw.data_hora).toLocaleTimeString("pt-BR", {
                hour: "2-digit",
                minute: "2-digit",
              });

              return (
                <Box key={ev.id} sx={{ p: 2, mb: 2, borderRadius: 2, background: "#f5f9fc", border: "1px solid #dce6ef" }}>
                  <Typography><b>Paciente:</b> {ev.raw.Paciente?.nome}</Typography>
                  <Typography><b>Procedimento:</b> {ev.raw.Procedimento?.nome}</Typography>
                  <Typography><b>Dentista:</b> {getDentistaNome(ev.raw.usuario_id)}</Typography>
                  <Typography><b>Horário:</b> {h}</Typography>
                  <Typography><b>Status:</b> {ev.raw.status}</Typography>

                  <Box sx={{ display: "flex", justifyContent: "flex-end", gap: 1, mt: 1 }}>
                    <Button
                      variant="outlined"
                      size="small"
                      startIcon={<EditIcon />}
                      onClick={() => handleOpenNovoModal(selectedDate, ev.raw)}
                    >
                      Editar
                    </Button>

                    <Button
                      variant="contained"
                      size="small"
                      color="error"
                      startIcon={<DeleteIcon />}
                      onClick={() => handleDeleteAgendamento(ev.id)}
                    >
                      Excluir
                    </Button>
                  </Box>
                </Box>
              );
            })
          )}

          <Button
            variant="contained"
            fullWidth
            startIcon={<AddIcon />}
            sx={{ background: "#5BA3C3", mt: 1 }}
            onClick={() => handleOpenNovoModal(selectedDate)}
          >
            Agendar neste dia
          </Button>
        </Box>
      </Modal>

      {/* =====================================================================
          MODAL NOVO / EDITAR
      ===================================================================== */}
      <Modal open={openNovoModal} onClose={() => setOpenNovoModal(false)}>
        <Box sx={{
          position: "absolute", top: "50%", left: "50%",
          transform: "translate(-50%, -50%)",
          width: 500, bgcolor: "#fff", p: 3, borderRadius: 2
        }}>
          <Typography variant="h5" fontWeight={600} sx={{ mb: 3 }}>
            {editingAgendamentoId ? "Editar Agendamento" : "Novo Agendamento"}
          </Typography>

          {/* PACIENTE */}
          <TextField
            select fullWidth sx={{ mb: 2 }}
            label="Paciente"
            name="paciente_id"
            value={formAgendamento.paciente_id}
            onChange={handleChangeNovo}
          >
            {pacientes.map(p => (
              <MenuItem key={p.id} value={p.id}>{p.nome}</MenuItem>
            ))}
          </TextField>

          {/* PROCEDIMENTO */}
          <TextField
            select fullWidth sx={{ mb: 2 }}
            label="Procedimento"
            name="procedimento_id"
            value={formAgendamento.procedimento_id}
            onChange={handleChangeNovo}
          >
            {procedimentos.map(p => (
              <MenuItem key={p.id} value={p.id}>{p.nome}</MenuItem>
            ))}
          </TextField>

          {/* DENTISTA */}
          <TextField
            select fullWidth sx={{ mb: 2 }}
            label="Dentista"
            name="usuario_id"
            value={formAgendamento.usuario_id}
            onChange={handleChangeNovo}
          >
            {dentistas.map(d => (
              <MenuItem key={d.id} value={d.id}>{d.nome}</MenuItem>
            ))}
          </TextField>

          {/* DATA + HORA */}
          <Box sx={{ display: "flex", gap: 2, mb: 2 }}>
            <TextField
              type="date"
              fullWidth
              label="Data"
              name="data"
              InputLabelProps={{ shrink: true }}
              value={formAgendamento.data}
              onChange={handleChangeNovo}
            />
            <TextField
              type="time"
              fullWidth
              label="Hora"
              name="hora"
              InputLabelProps={{ shrink: true }}
              value={formAgendamento.hora}
              onChange={handleChangeNovo}
            />
          </Box>

          {/* OBSERVAÇÕES */}
          <TextField
            multiline rows={3} fullWidth sx={{ mb: 3 }}
            label="Observações"
            name="observacoes"
            value={formAgendamento.observacoes}
            onChange={handleChangeNovo}
          />

          {/* BOTÃO SALVAR */}
          <Button
            variant="contained"
            fullWidth
            sx={{ background: "#5BA3C3" }}
            onClick={editingAgendamentoId ? handleUpdate : handleNovo}
          >
            {editingAgendamentoId ? "Salvar Alterações" : "Salvar Agendamento"}
          </Button>
        </Box>
      </Modal>

    </Box>
  );
}
