import { useEffect, useState } from "react";
import { Routes, Route, Navigate } from "react-router-dom";

import Login from "./Pages/Login";
import Dashboard from "./Pages/Dash";
import Agenda from "./Pages/Agenda";
import Paciente from "./Pages/Paciente";
import Procedimento from "./Pages/Procedimentos";

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (token) setIsLoggedIn(true);
  }, []);

  return (
    <Routes>
      {/* ===== ROTA LOGIN ===== */}
      <Route
        path="/"
        element={
          isLoggedIn ? (
            <Navigate to="/dashboard" />
          ) : (
            <Login setIsLoggedIn={setIsLoggedIn} />
          )
        }
      />

      {/* ===== ROTA DASHBOARD ===== */}
      <Route
        path="/dashboard"
        element={
          isLoggedIn ? (
            <Dashboard setIsLoggedIn={setIsLoggedIn} />
          ) : (
            <Navigate to="/" />
          )
        }
      />

      {/* ===== ROTA AGENDA ===== */}
     <Route
  path="/agenda"
  element={
    isLoggedIn ? (
      <Agenda setIsLoggedIn={setIsLoggedIn} />
    ) : (
      <Navigate to="/" />
    )
  }
/>

<Route
  path="/pacientes"
  element={
    isLoggedIn ? (
      <Paciente setIsLoggedIn={setIsLoggedIn} />
    ) : (
      <Navigate to="/" />
    )
  }
/>

<Route
  path="/procedimentos"
  element={
    isLoggedIn ? (
      <Procedimento setIsLoggedIn={setIsLoggedIn} />
    ) : (
      <Navigate to="/" />
    )
  }
/>
    </Routes>
  );
}
