import { useEffect, useState } from "react";
import { Routes, Route, Navigate } from "react-router-dom";

import Login from "./Pages/Login";
import Dashboard from "./Pages/Dash";
import Agenda from "./Pages/Agenda";
import Paciente from "./Pages/Paciente";
import Procedimento from "./Pages/Procedimentos";

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [canSeeDashboard, setCanSeeDashboard] = useState(false);

useEffect(() => {
  const token = localStorage.getItem("token");
  const permissoes = JSON.parse(localStorage.getItem("permissoes") || "[]");

  if (token) setIsLoggedIn(true);
  if (permissoes.includes("VIZUALIZAR_DASH")) setCanSeeDashboard(true);
}, []);

  return (
    <Routes>
      {/* ========== LOGIN ========== */}
      <Route
        path="/"
        element={
          isLoggedIn ? (
            <Navigate to={canSeeDashboard ? "/dashboard" : "/agenda"} />
          ) : (
            <Login
              setIsLoggedIn={setIsLoggedIn}
              setCanSeeDashboard={setCanSeeDashboard}
            />
          )
        }
      />

      {/* ========== DASHBOARD (somente se tiver permissão) ========== */}
      <Route
        path="/dashboard"
        element={
          isLoggedIn && canSeeDashboard ? (
            <Dashboard setIsLoggedIn={setIsLoggedIn} />
          ) : (
            <Navigate to="/agenda" />
          )
        }
      />

      {/* ========== AGENDA ========== */}
      <Route
        path="/agenda"
        element={
          isLoggedIn ? (
            <Agenda setIsLoggedIn={setIsLoggedIn} />
          ) : (
            <Navigate to="/" />
          )
        }
      />

      {/* ========== PACIENTES ========== */}
      <Route
        path="/pacientes"
        element={
          isLoggedIn ? (
            <Paciente setIsLoggedIn={setIsLoggedIn} />
          ) : (
            <Navigate to="/" />
          )
        }
      />

      {/* ========== PROCEDIMENTOS ========== */}
      <Route
        path="/procedimentos"
        element={
          isLoggedIn ? (
            <Procedimento setIsLoggedIn={setIsLoggedIn} />
          ) : (
            <Navigate to="/" />
          )
        }
      />
    </Routes>
  );
}
