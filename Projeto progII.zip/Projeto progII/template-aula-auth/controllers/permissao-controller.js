const express = require("express");
const permissaoService = require("../services/permissao-service");
const authService = require("../services/auth-service");

const router = express.Router();

// ==================== ROTAS DE PERMISSÃO ====================

// Aplica autenticação JWT em todas as rotas deste router
router.use(authService.requireJWTAuth);

// POST /permissao - cria nova permissão
router.post("/", permissaoService.criaPermissao);

// GET /permissao/todos - retorna todas as permissões
router.get("/todos", permissaoService.retornaTodasPermissoes);

// GET /permissao/:id - retorna permissão por ID
router.get("/:id", permissaoService.retornaPermissaoPorId);

// PUT /permissao/:id - atualiza permissão existente
router.put("/:id", permissaoService.atualizaPermissao);

// DELETE /permissao/:id - deleta permissão
router.delete("/:id", permissaoService.deletaPermissao);

module.exports = router;
