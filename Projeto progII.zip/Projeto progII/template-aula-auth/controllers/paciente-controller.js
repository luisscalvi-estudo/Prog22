const express = require("express");
const pacienteService = require("../services/paciente-service");
const authService = require("../services/auth-service");

const router = express.Router();

// ==================== ROTAS DE PACIENTE ====================

// Aplica autenticação JWT em todas as rotas deste router
router.use(authService.requireJWTAuth);

// GET /pacientes - retorna todos os pacientes
router.get("/", pacienteService.retornaTodos);

// GET /pacientes/:id - retorna paciente por ID
router.get("/:id", pacienteService.retornaPorId);

// POST /pacientes - cria um novo paciente
router.post("/", pacienteService.cria);

// PUT /pacientes/:id - atualiza um paciente existente
router.put("/:id", pacienteService.atualiza);

// DELETE /pacientes/:id - deleta um paciente
router.delete("/:id", pacienteService.deleta);

module.exports = router;
