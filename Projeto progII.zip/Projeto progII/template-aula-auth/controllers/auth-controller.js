const express = require("express");
const passport = require("passport");
const authService = require("../services/auth-service");

const authRouter = express.Router();

// ======================== LOGIN ========================
authRouter.post(
  "/login",
  passport.authenticate("local", { session: false }),
  (req, res) => {
    try {
      // Gera token JWT com os dados do usuário
      const token = authService.gerarToken(req.user);

      res.json({
        message: "Login successful",
        token,
        user: {
          id: req.user.id,
          email: req.user.email,
          nome: req.user.nome,
        },
      });
    } catch (err) {
      console.error("Erro no login:", err);
      res.status(500).json({ message: "Erro ao realizar login" });
    }
  }
);

// ======================== LOGOUT ========================
authRouter.post("/logout", (req, res) => {
  res.json({ message: "Logout efetuado (JWT não mantém sessão)" });
});

// ======================== CRIAR NOVO USUÁRIO ========================
authRouter.post("/novoUsuario", async (req, res) => {
  try {
    const { nome, email, senha } = req.body;

    // Cria usuário sem eh_dentista
    await authService.criarNovoUsuario({
      nome,
      email,
      senha,
    });

    res.status(201).json({ message: "Usuário criado com sucesso!" });
  } catch (error) {
    console.error("Erro ao criar usuário:", error);
    res.status(400).json({ message: "Erro ao criar usuário" });
  }
});

module.exports = authRouter;
