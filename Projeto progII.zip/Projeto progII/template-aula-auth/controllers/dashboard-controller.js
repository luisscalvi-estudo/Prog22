const express = require("express");
const router = express.Router();
const dashboardService = require("../services/dashboard-service");
const authService = require("../services/auth-service");

// ======================== DASHBOARD ========================
// GET /dashboard - retorna informações do dashboard
router.get(
  "/",
  authService.requireJWTAuth, // garante que só usuários autenticados acessem
  async (req, res) => {
    try {
      const data = await dashboardService.getDashboardInfo();
      return res.status(200).json(data);
    } catch (error) {
      console.error("Erro ao carregar Dashboard:", error);
      return res.status(500).json({ error: "Erro ao carregar Dashboard" });
    }
  }
);

module.exports = router;