"use strict";

module.exports = (sequelize, DataTypes) => {
    const Paciente = sequelize.define(
        "Paciente",
        {
            id: {
                type: DataTypes.INTEGER,
                primaryKey: true,
                autoIncrement: true
            },
            nome: DataTypes.STRING,
            telefone: DataTypes.STRING,
            email: DataTypes.STRING,
            criado_em: DataTypes.DATE
        },
        {
            tableName: "pacientes",
            timestamps: false,
        }
    );

    Paciente.associate = function (models) {
        Paciente.hasMany(models.Agendamento, {
            foreignKey: "paciente_id"
        });
    };

    return Paciente;
};
