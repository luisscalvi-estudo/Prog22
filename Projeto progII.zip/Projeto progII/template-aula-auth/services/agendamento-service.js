const agRepo = require("../repositories/agendamento-repository");
const { DateTime } = require("luxon");

// ==================== LISTAR ====================
// Retorna todos os agendamentos, com filtro opcional por usuário
const retornaTodos = async (req, res) => {
    try {
        const { usuario_id } = req.query; // filtro do front
        let filtro = {};

        if (usuario_id && usuario_id !== "all") {
            filtro.usuario_id = Number(usuario_id);
        }

        const lista = await agRepo.obterTodos(filtro);

        // Ajusta horário para o front (UTC → America/Sao_Paulo)
        const ajustado = lista.map(item => {
            const dt = DateTime
                .fromJSDate(item.data_hora, { zone: "utc" })
                .setZone("America/Sao_Paulo");

            return {
                ...item.toJSON(),
                data_hora: dt.toISO({ suppressMilliseconds: true })
            };
        });

        res.status(200).json({ agendamentos: ajustado });
    } catch (error) {
        console.error("Erro ao buscar agendamentos:", error);
        res.sendStatus(500);
    }
};

// ==================== BUSCAR POR ID ====================
// Retorna um agendamento específico pelo ID
const retornaPorId = async (req, res) => {
    try {
        const id = parseInt(req.params.id);
        const item = await agRepo.obterPorId({ id });

        if (!item) {
            return res.status(404).json({ message: "Agendamento não encontrado." });
        }

        const dt = DateTime
            .fromJSDate(item.data_hora, { zone: "utc" })
            .setZone("America/Sao_Paulo");

        res.status(200).json({
            ...item.toJSON(),
            data_hora: dt.toISO({ suppressMilliseconds: true })
        });
    } catch (error) {
        console.error("Erro ao buscar agendamento por ID:", error);
        res.sendStatus(500);
    }
};

// ==================== CRIAR ====================
// Cria um novo agendamento
const cria = async (req, res) => {
    try {
        const { paciente_id, procedimento_id, data_hora, status, observacoes, usuario_id } = req.body;

        // Converte string de data/hora para objeto Date (America/Sao_Paulo)
        const dataHoraLocal = DateTime.fromISO(data_hora, { zone: 'America/Sao_Paulo' });
        if (!dataHoraLocal.isValid) {
            return res.status(400).json({ message: "Formato de data/hora inválido." });
        }
        const dataHoraAjustada = dataHoraLocal.toJSDate();

        const novo = await agRepo.criar({
            paciente_id,
            procedimento_id,
            data_hora: dataHoraAjustada,
            status: status || "PENDENTE",
            observacoes,
            usuario_id: usuario_id || null,
        });

        res.status(201).json(novo);
    } catch (error) {
        console.error("Erro ao criar agendamento:", error);
        res.sendStatus(500);
    }
};

// ==================== ATUALIZAR ====================
// Atualiza um agendamento existente
const atualiza = async (req, res) => {
    try {
        const id = parseInt(req.params.id);
        const { paciente_id, procedimento_id, data_hora, status, observacoes, usuario_id } = req.body;

        let dataHoraAjustada = data_hora;
        if (data_hora) {
            const dataHoraLocal = DateTime.fromISO(data_hora, { zone: 'America/Sao_Paulo' });
            if (!dataHoraLocal.isValid) {
                return res.status(400).json({ message: "Formato de data/hora inválido." });
            }
            dataHoraAjustada = dataHoraLocal.toJSDate();
        }

        const atualizado = await agRepo.atualizar({
            id,
            paciente_id,
            procedimento_id,
            data_hora: dataHoraAjustada,
            status,
            observacoes,
            usuario_id: usuario_id || null,
        });

        res.status(200).json(atualizado);
    } catch (error) {
        console.error("Erro ao atualizar agendamento:", error);
        res.sendStatus(500);
    }
};

// ==================== DELETAR ====================
// Deleta um agendamento pelo ID
const deleta = async (req, res) => {
    try {
        const id = parseInt(req.params.id);
        await agRepo.deletar({ id });
        res.status(200).json({ message: "Agendamento removido." });
    } catch (error) {
        console.error("Erro ao deletar agendamento:", error);
        res.sendStatus(500);
    }
};

module.exports = {
    retornaTodos,
    retornaPorId,
    cria,
    atualiza,
    deleta,
};
