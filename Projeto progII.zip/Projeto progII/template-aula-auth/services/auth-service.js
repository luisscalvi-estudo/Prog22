const passport = require("passport");
const LocalStrategy = require("passport-local").Strategy;
const JwtStrategy = require("passport-jwt").Strategy;
const ExtractJwt = require("passport-jwt").ExtractJwt;
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const model = require("../models");

// ======================================================
//  LOCAL STRATEGY - login com email + senha
// ======================================================
const configureLocalStrategy = () => {
    passport.use(
        new LocalStrategy(
            { usernameField: "email", passwordField: "senha" },
            async (email, senha, done) => {
                try {
                    console.log("Tentando autenticar:", email);

                    const user = await model.Usuario.findOne({ where: { email } });
                    if (!user) return done(null, false); // usuário não encontrado

                    const passwordMatch = await bcrypt.compare(senha, user.senha);
                    if (!passwordMatch) return done(null, false); // senha incorreta

                    console.log("Login OK — usuário:", user.id);
                    return done(null, user);

                } catch (error) {
                    console.error("Erro no LocalStrategy:", error);
                    return done(error);
                }
            }
        )
    );
};

// ======================================================
//  JWT STRATEGY - validação de token
// ======================================================
const configureJwtStrategy = () => {
    passport.use(
        new JwtStrategy(
            {
                jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
                secretOrKey: "UMA-COISA-DOIDA",
            },
            async (payload, done) => {
                try {
                    const user = await model.Usuario.findByPk(payload.id);
                    if (!user) return done(null, false);
                    return done(null, user);
                } catch (error) {
                    console.error("Erro no JwtStrategy:", error);
                    return done(error, false);
                }
            }
        )
    );
};

// ======================================================
//  SERIALIZAÇÃO / DESERIALIZAÇÃO DO PASSPORT
// ======================================================
const configureSerialization = () => {
    passport.serializeUser((user, done) => done(null, { id: user.id, email: user.email }));
    passport.deserializeUser((data, done) => done(null, data));
};

// ======================================================
//  CRIAR NOVO USUÁRIO
// ======================================================
const criarNovoUsuario = async ({ email, senha, nome }) => {
    await model.Usuario.create({ email, nome, senha });
    return { email, nome };
};

// ======================================================
//  GERAR TOKEN JWT
// ======================================================
const gerarToken = (usuario) => {
    return jwt.sign({ id: usuario.id, email: usuario.email }, "UMA-COISA-DOIDA", { expiresIn: "1h" });
};

// ======================================================
//  MIDDLEWARE PARA PROTEGER ROTAS (JWT)
// ======================================================
const requireJWTAuth = passport.authenticate("jwt", { session: false });

// ======================================================
//  PERMISSÕES
// ======================================================

// Verifica se usuário tem permissão específica
const verificarPermissaoPorDescricao = async (email, descricaoPermissao) => {
    try {
        const permissao = await model.Permissao.findOne({ where: { descricao: descricaoPermissao } });
        if (!permissao) return false;

        const usuarioPermissao = await model.UsuarioPermissao.findOne({
            where: { email, id_permissao: permissao.id },
        });

        return usuarioPermissao !== null;
    } catch (error) {
        console.error("Erro ao verificar permissão:", error);
        return false;
    }
};

// Retorna todas as permissões de um usuário
const obterPermissoesUsuario = async (email) => {
    try {
        const permissoes = await model.UsuarioPermissao.findAll({
            where: { email },
            include: [{ model: model.Permissao, as: "Permissao" }],
        });

        return permissoes.map((up) => up.Permissao);
    } catch (error) {
        console.error("Erro ao obter permissões do usuário:", error);
        return [];
    }
};

// Middleware para checar permissão em rotas
const verificarPermissaoMiddleware = (descricaoPermissao) => {
    return [
        requireJWTAuth,
        async (req, res, next) => {
            if (!req.user) return res.status(401).json({ message: "Usuário não autenticado." });

            const temPermissao = await verificarPermissaoPorDescricao(req.user.email, descricaoPermissao);
            if (!temPermissao) {
                return res.status(403).json({
                    message: `Acesso negado. Permissão necessária: ${descricaoPermissao}`,
                });
            }

            next();
        },
    ];
};

// ======================================================
//  EXPORTAR FUNÇÕES
// ======================================================
module.exports = {
    configureLocalStrategy,
    configureJwtStrategy,
    configureSerialization,
    criarNovoUsuario,
    gerarToken,
    requireJWTAuth,
    verificarPermissaoPorDescricao,
    obterPermissoesUsuario,
    verificarPermissaoMiddleware,
    requirePermissao: verificarPermissaoMiddleware,
};
