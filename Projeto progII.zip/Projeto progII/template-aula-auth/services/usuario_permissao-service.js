const usuarioPermissaoRepository = require("../repositories/usuario_permissao-repository");

// ==================== LISTAR TODAS AS ASSOCIAÇÕES ====================
const retornaTodosUsuarioPermissoes = async (req, res) => {
    try {
        const usuarioPermissoes = await usuarioPermissaoRepository.obterTodosUsuarioPermissoes();
        res.status(200).json({ usuarioPermissoes });
    } catch (error) {
        console.error("Erro ao buscar usuário-permissões:", error);
        res.sendStatus(500);
    }
};

// ==================== PERMISSÕES DE UM USUÁRIO ====================
const retornaPermissoesPorUsuario = async (req, res) => {
    try {
        const email = req.params.email;
        const permissoes = await usuarioPermissaoRepository.obterPermissoesPorUsuario(email);
        res.status(200).json({ permissoes });
    } catch (error) {
        console.error("Erro ao buscar permissões do usuário:", error);
        res.sendStatus(500);
    }
};

// ==================== USUÁRIOS POR PERMISSÃO ====================
const retornaUsuariosPorPermissao = async (req, res) => {
    try {
        const id_permissao = parseInt(req.params.id_permissao);
        const usuarios = await usuarioPermissaoRepository.obterUsuariosPorPermissao(id_permissao);
        res.status(200).json({ usuarios });
    } catch (error) {
        console.error("Erro ao buscar usuários por permissão:", error);
        res.sendStatus(500);
    }
};

// ==================== CRIAR ASSOCIAÇÃO ====================
const criaUsuarioPermissao = async (req, res) => {
    const { email, id_permissao } = req.body;

    if (!email || !id_permissao) {
        return res.status(400).json({ message: "Email e ID da permissão são obrigatórios." });
    }

    try {
        const usuarioPermissao = await usuarioPermissaoRepository.criarUsuarioPermissao({ email, id_permissao });
        res.status(201).json(usuarioPermissao);
    } catch (error) {
        console.error("Erro ao criar usuário-permissão:", error);
        res.sendStatus(500);
    }
};

// ==================== DELETAR ASSOCIAÇÃO ====================
const deletaUsuarioPermissao = async (req, res) => {
    try {
        const email = req.params.email;
        const id_permissao = parseInt(req.params.id_permissao);

        const removida = await usuarioPermissaoRepository.deletarUsuarioPermissao({ email, id_permissao });

        if (removida) {
            res.status(200).json({
                message: "Associação usuário-permissão removida com sucesso.",
                usuarioPermissao: removida,
            });
        } else {
            res.status(404).json({ message: "Associação usuário-permissão não encontrada." });
        }
    } catch (error) {
        console.error("Erro ao deletar usuário-permissão:", error);
        res.status(500).json({ message: "Erro ao deletar usuário-permissão." });
    }
};

// ==================== VERIFICAR PERMISSÃO ====================
const verificaPermissaoUsuario = async (req, res) => {
    try {
        const email = req.params.email;
        const id_permissao = parseInt(req.params.id_permissao);

        const temPermissao = await usuarioPermissaoRepository.verificarPermissaoUsuario(email, id_permissao);

        res.status(200).json({ email, id_permissao, temPermissao });
    } catch (error) {
        console.error("Erro ao verificar permissão do usuário:", error);
        res.sendStatus(500);
    }
};

module.exports = {
    retornaTodosUsuarioPermissoes,
    retornaPermissoesPorUsuario,
    retornaUsuariosPorPermissao,
    criaUsuarioPermissao,
    deletaUsuarioPermissao,
    verificaPermissaoUsuario,
};
