const model = require("../models");

const obterTodos = async () => {
	return await model.Paciente.findAll();
};

const obterPorId = async (paciente) => {
	return await model.Paciente.findByPk(paciente.id);
};

const criar = async (paciente) => {
	return await model.Paciente.create(paciente);
};

const atualizar = async (paciente) => {
	await model.Paciente.update(paciente, { where: { id: paciente.id } });
	return await model.Paciente.findByPk(paciente.id);
};

const deletar = async (paciente) => {
	await model.Paciente.destroy({ where: { id: paciente.id } });
	return paciente;
};

module.exports = { obterTodos, obterPorId, criar, atualizar, deletar };
