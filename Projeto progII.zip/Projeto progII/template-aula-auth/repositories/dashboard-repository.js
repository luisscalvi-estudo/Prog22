const model = require("../models");
const { Op } = require("sequelize");
const moment = require("moment");

// ==================== DASHBOARD SERVICE ====================
// Retorna resumo de informações para o dashboard
const obterResumoDashboard = async () => {
    const hoje = moment().startOf("day");         // início do dia atual
    const inicioMes = moment().startOf("month");  // início do mês atual

    // Total de pacientes cadastrados
    const totalPacientes = await model.Paciente.count();

    // Consultas agendadas para hoje
    const consultasHoje = await model.Agendamento.count({
        where: {
            data_hora: {
                [Op.between]: [hoje.toDate(), moment(hoje).endOf("day").toDate()]
            }
        }
    });

    // Procedimentos realizados no mês
    const procedimentosMes = await model.Agendamento.count({
        where: {
            data_hora: {
                [Op.between]: [inicioMes.toDate(), moment().endOf("month").toDate()]
            },
            status: "REALIZADO"
        }
    });

    // Faturamento do mês (somando preço de cada procedimento realizado)
    const faturamentoMes = await model.Agendamento.findAll({
        where: {
            data_hora: {
                [Op.between]: [inicioMes.toDate(), moment().endOf("month").toDate()]
            },
            status: "REALIZADO"
        },
        include: [model.Procedimento]
    });

    const totalFaturamento = faturamentoMes.reduce(
        (acc, ag) => acc + (ag.Procedimento?.preco || 0), // soma preços
        0
    );

    // Próximas 5 consultas agendadas
    const proximasConsultas = await model.Agendamento.findAll({
        where: {
            data_hora: { [Op.gt]: moment().toDate() } // após agora
        },
        include: [model.Paciente],
        limit: 5,
        order: [["data_hora", "ASC"]]
    });

    // Consultas por mês (últimos 4 meses)
    const consultasPorMes = [];
    for (let i = 3; i >= 0; i--) {
        const inicio = moment().subtract(i, "months").startOf("month");
        const fim = moment().subtract(i, "months").endOf("month");

        const qtd = await model.Agendamento.count({
            where: {
                data_hora: {
                    [Op.between]: [inicio.toDate(), fim.toDate()]
                }
            }
        });

        consultasPorMes.push({
            mes: inicio.format("MMM").toUpperCase(), // ex: JAN, FEB
            consultas: qtd
        });
    }

    return {
        totalPacientes,
        consultasHoje,
        procedimentosMes,
        faturamentoMes: totalFaturamento,
        proximasConsultas,
        consultasPorMes
    };
};

module.exports = {
    obterResumoDashboard
};
