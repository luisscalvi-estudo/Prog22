import "../CSS/Dash.css";
import "../CSS/Paciente_e_Procedimento.css";

import { useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import axios from "axios";

import {
  Box,
  Avatar,
  IconButton,
  Modal,
  TextField,
  Button
} from "@mui/material";

import {
  Home as HomeIcon,
  EventNote as CalendarIcon,
  People as PeopleIcon,
  Settings as SettingsIcon,
  Logout as LogoutIcon,
  Edit,
  Delete,
  Vaccines as MedicineIcon,
} from "@mui/icons-material";

// ======================= FUNÇÕES DE FORMATAÇÃO =======================
function formatarData(dataString) {
  if (!dataString) return "--";
  const data = new Date(dataString);
  return data.toLocaleDateString("pt-BR");
}

function formatarTelefone(telefone) {
  if (!telefone) return "--";
  const apenasDigitos = String(telefone).replace(/\D/g, '');
  if (apenasDigitos.length === 11) {
    return apenasDigitos.replace(/^(\d{2})(\d{5})(\d{4})$/, '($1) $2-$3');
  } else if (apenasDigitos.length === 10) {
    return apenasDigitos.replace(/^(\d{2})(\d{4})(\d{4})$/, '($1) $2-$3');
  }
  return telefone; 
}

const maskTelefone = (valor) => {
  let digitos = valor.replace(/\D/g, "");
  if (digitos.length > 11) digitos = digitos.substring(0, 11);
  if (digitos.length > 2) digitos = `(${digitos.substring(0, 2)}) ${digitos.substring(2)}`;
  if (digitos.length > 9 && digitos.length <= 14) {
    digitos = digitos.replace(/(\d{5})(\d{1,4})$/, '$1-$2');
  } else if (digitos.length > 9) {
    digitos = digitos.replace(/(\d{4})(\d{1,4})$/, '$1-$2');
  }
  return digitos;
};

// ============================================================================

export default function Paciente({ setIsLoggedIn }) {
  const navigate = useNavigate();

  /* ================= ESTADOS ================= */
  const [pacientes, setPacientes] = useState([]);
  const [busca, setBusca] = useState("");
  const [erroPermissao, setErroPermissao] = useState(null); 

  const [openModalNovo, setOpenModalNovo] = useState(false);
  const [formNovoPaciente, setFormNovoPaciente] = useState({
    nome: "",
    telefone: "",
    cpf: "",
    descricao: "",
    email: ""
  });

  const [openModalEdicao, setOpenModalEdicao] = useState(false);
  const [pacienteEmEdicao, setPacienteEmEdicao] = useState(null);

  // Estado reativo para dashboard
  const [canSeeDashboard, setCanSeeDashboard] = useState(() => {
    const permissoes = JSON.parse(localStorage.getItem("permissoes") || "[]");
    return permissoes.includes("VIZUALIZAR_DASH");
  });

  /* ================= CARREGAR PACIENTES ================= */
  const carregarPacientes = async () => {
    setErroPermissao(null);
    try {
      const token = localStorage.getItem("token");
      const response = await axios.get("http://localhost:3002/pacientes", {
        headers: { Authorization: `Bearer ${token}` }
      });
      setPacientes(response.data.pacientes);
    } catch (error) {
      console.error("Erro ao carregar pacientes:", error);
      if (error.response && (error.response.status === 401 || error.response.status === 403)) {
        setErroPermissao("Você não tem permissão para visualizar esta página.");
      } else {
        setErroPermissao("Ocorreu um erro ao carregar os dados. Tente novamente.");
      }
      setPacientes([]);
    }
  }

  useEffect(() => {
    carregarPacientes();
  }, []);

  const pacientesFiltrados = pacientes.filter(p =>
    p.nome.toLowerCase().includes(busca.toLowerCase()) ||
    (p.cpf && p.cpf.includes(busca))
  );

  /* ================= HANDLERS NOVO PACIENTE ================= */
  const handleChangeNovo = (e) => {
    const { name, value } = e.target;
    let newValue = value;
    if (name === 'telefone') newValue = maskTelefone(value);
    setFormNovoPaciente({ ...formNovoPaciente, [name]: newValue });
  };

  const handleSalvarNovo = async () => {
    try {
      const token = localStorage.getItem("token");
      const dadosParaEnviar = { ...formNovoPaciente, telefone: formNovoPaciente.telefone.replace(/\D/g, '') };
      await axios.post("http://localhost:3002/pacientes", dadosParaEnviar, {
        headers: { Authorization: `Bearer ${token}` }
      });
      alert("Paciente cadastrado!");
      await carregarPacientes();
      setOpenModalNovo(false);
      setFormNovoPaciente({ nome: "", telefone: "", cpf: "", descricao: "", email: "" });
    } catch (error) {
      console.error(error);
      alert("Erro ao cadastrar paciente.");
    }
  };

  /* ================= HANDLERS EDIÇÃO PACIENTE ================= */
  const handleOpenEditModal = (paciente) => {
    setPacienteEmEdicao({ ...paciente, telefone: maskTelefone(paciente.telefone || "") });
    setOpenModalEdicao(true);
  };

  const handleCloseModalEdicao = () => {
    setOpenModalEdicao(false);
    setPacienteEmEdicao(null);
  };

  const handleChangeEdicao = (e) => {
    const { name, value } = e.target;
    let newValue = value;
    if (name === 'telefone') newValue = maskTelefone(value);
    setPacienteEmEdicao(prev => ({ ...prev, [name]: newValue }));
  };

  const handleSalvarEdicao = async () => {
    if (!pacienteEmEdicao) return;
    try {
      const token = localStorage.getItem("token");
      const dadosParaEnviar = {
        nome: pacienteEmEdicao.nome,
        email: pacienteEmEdicao.email,
        telefone: pacienteEmEdicao.telefone.replace(/\D/g, ''), 
        cpf: pacienteEmEdicao.cpf,
        descricao: pacienteEmEdicao.descricao || "", 
      };
      await axios.put(`http://localhost:3002/pacientes/${pacienteEmEdicao.id}`, dadosParaEnviar, {
        headers: { Authorization: `Bearer ${token}` }
      });
      alert("Paciente atualizado com sucesso!");
      await carregarPacientes();
      handleCloseModalEdicao();
    } catch (error) {
      console.error("Erro ao atualizar paciente:", error);
      alert("Erro ao atualizar paciente.");
    }
  };

  /* ================= HANDLER EXCLUSÃO PACIENTE ================= */
  const handleDelete = async (pacienteId, nomePaciente) => {
    if (window.confirm(`Tem certeza que deseja excluir o paciente ${nomePaciente}?`)) {
      try {
        const token = localStorage.getItem("token");
        await axios.delete(`http://localhost:3002/pacientes/${pacienteId}`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        alert(`Paciente ${nomePaciente} excluído com sucesso.`);
        await carregarPacientes();
      } catch (error) {
        console.error("Erro ao excluir paciente:", error);
        alert("Erro ao excluir paciente.");
      }
    }
  };

  /* ================= LOGOUT ================= */
  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("permissoes");
    setIsLoggedIn(false);
    navigate("/");
  };

  return (
    <Box className="dashboard-layout">

      {/* ================= SIDEBAR ================= */}
      <Box className="sidebar">
        <Box className="sidebar-logo">
          <Avatar sx={{ width: 48, height: 48, backgroundColor: "#fff", color: "#5BA3C3", fontWeight: "bold" }}>M</Avatar>
        </Box>

        <Box className="sidebar-nav">
          {canSeeDashboard && (
            <IconButton className="nav-icon" onClick={() => navigate("/dashboard")}>
              <HomeIcon />
            </IconButton>
          )}

          <IconButton className="nav-icon" onClick={() => navigate("/agenda")}>
            <CalendarIcon />
          </IconButton>

          <IconButton className="nav-icon active">
            <PeopleIcon />
          </IconButton>

          <IconButton className="nav-icon" onClick={() => navigate("/procedimentos")}>
            <MedicineIcon />
          </IconButton>

          <IconButton className="nav-icon">
            <SettingsIcon />
          </IconButton>

          <div className="sidebar-logout">
            <IconButton className="nav-icon logout-btn" onClick={handleLogout}>
              <LogoutIcon />
            </IconButton>
          </div>
        </Box>
      </Box>

      {/* ================= CONTEÚDO PRINCIPAL ================= */}
      <Box className="pacientes-container">
        <h1 className="titulo-pagina">GESTÃO DE PACIENTES</h1>

        {erroPermissao ? (
          <div style={{
            color: '#D32F2F', backgroundColor: '#FFEBEE', border: '1px solid #EF9A9A',
            padding: '20px', borderRadius: '8px', marginTop: '20px',
            textAlign: 'center', fontSize: '1.2rem', fontWeight: 'bold'
          }}>
            {erroPermissao}
          </div>
        ) : (
          <>
            <div className="linha-superior">
              <input type="text" className="input-busca" placeholder="Buscar paciente por nome"
                value={busca} onChange={(e) => setBusca(e.target.value)}
              />
              <button className="btn-novo" onClick={() => setOpenModalNovo(true)}>+ NOVO PACIENTE</button>
            </div>

            <table className="tabela-pacientes">
              <thead>
                <tr>
                  <th>NOME</th><th>E-MAIL</th><th>TELEFONE</th><th>CRIADO EM</th><th>AÇÕES</th>
                </tr>
              </thead>
              <tbody>
                {pacientesFiltrados.length === 0 && (
                  <tr>
                    <td colSpan="5" style={{ textAlign: "center", padding: "25px", opacity: 0.6 }}>
                      Nenhum paciente encontrado.
                    </td>
                  </tr>
                )}

                {pacientesFiltrados.map((p) => (
                  <tr key={p.id}>
                    <td>{p.nome}</td>
                    <td>{p.email || "--"}</td>
                    <td>{formatarTelefone(p.telefone)}</td>
                    <td>{formatarData(p.criado_em)}</td>
                    <td className="acoes">
                      <Edit className="icon-acao" onClick={() => handleOpenEditModal(p)} />
                      <Delete className="icon-acao delete" onClick={() => handleDelete(p.id, p.nome)} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </>
        )}
      </Box>

      {/* ================= MODAL NOVO PACIENTE ================= */}
      <Modal open={openModalNovo} onClose={() => setOpenModalNovo(false)}>
        <Box sx={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%, -50%)",
          background: "#fff", borderRadius: "12px", padding: "30px", width: "420px", boxShadow: 5 }}>
          <h2>Novo Paciente</h2>
          <TextField label="Nome" name="nome" fullWidth sx={{ mb: 2 }} value={formNovoPaciente.nome} onChange={handleChangeNovo} />
          <TextField label="E-mail" name="email" type="email" fullWidth sx={{ mb: 2 }} value={formNovoPaciente.email} onChange={handleChangeNovo} />
          <TextField label="Telefone" name="telefone" fullWidth sx={{ mb: 2 }} value={formNovoPaciente.telefone} onChange={handleChangeNovo} />
          <TextField label="Observações" name="descricao" fullWidth multiline rows={3} sx={{ mb: 3 }} value={formNovoPaciente.descricao} onChange={handleChangeNovo} />
          <Button variant="contained" fullWidth sx={{ background: "#5BA3C3" }} onClick={handleSalvarNovo}>Salvar</Button>
        </Box>
      </Modal>

      {/* ================= MODAL EDIÇÃO PACIENTE ================= */}
      {pacienteEmEdicao && (
        <Modal open={openModalEdicao} onClose={handleCloseModalEdicao}>
          <Box sx={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%, -50%)",
            background: "#fff", borderRadius: "12px", padding: "30px", width: "420px", boxShadow: 5 }}>
            <h2>Editar Paciente: {pacienteEmEdicao.nome}</h2>
            <TextField label="Nome" name="nome" fullWidth sx={{ mb: 2 }} value={pacienteEmEdicao.nome} onChange={handleChangeEdicao} />
            <TextField label="E-mail" name="email" type="email" fullWidth sx={{ mb: 2 }} value={pacienteEmEdicao.email || ''} onChange={handleChangeEdicao} />
            <TextField label="CPF" name="cpf" fullWidth sx={{ mb: 2 }} value={pacienteEmEdicao.cpf || ''} onChange={handleChangeEdicao} />
            <TextField label="Telefone" name="telefone" fullWidth sx={{ mb: 2 }} value={pacienteEmEdicao.telefone || ''} onChange={handleChangeEdicao} />
            <TextField label="Observações" name="descricao" fullWidth multiline rows={3} sx={{ mb: 3 }} value={pacienteEmEdicao.descricao || ''} onChange={handleChangeEdicao} />
            <Button variant="contained" fullWidth sx={{ background: "#5BA3C3" }} onClick={handleSalvarEdicao}>Salvar Alterações</Button>
          </Box>
        </Modal>
      )}

    </Box>
  );
}
