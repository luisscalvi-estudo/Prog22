import "../CSS/Dash.css";
import "../CSS/Paciente_e_Procedimento.css"; // Reutilizando estilos

import { useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import axios from "axios";

import {
  Box,
  Avatar,
  IconButton,
  Modal,
  TextField,
  Button
} from "@mui/material";

import {
  Home as HomeIcon,
  EventNote as CalendarIcon,
  People as PeopleIcon,
  Settings as SettingsIcon,
  Logout as LogoutIcon,
  Edit,
  Delete,
  Vaccines as MedicineIcon,
} from "@mui/icons-material";

// ======================= FUNÇÕES DE FORMATAÇÃO =======================

/**
 * Formata a data ISO para DD/MM/AAAA.
 */
function formatarData(dataString) {
  if (!dataString) return "--";
  const data = new Date(dataString);
  return data.toLocaleDateString("pt-BR");
}

/**
 * Formata um valor numérico para o padrão monetário BRL (R$ X.XXX,XX).
 */
function formatarPreco(preco) {
  if (preco === undefined || preco === null) return "R$ 0,00";
  
  let precoNumerico;
  
  if (typeof preco === 'string') {
    precoNumerico = parseFloat(preco); 
  } else {
    precoNumerico = preco;
  }
  
  if (isNaN(precoNumerico)) return "R$ 0,00";

  return precoNumerico.toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

// ============================================================================

export default function Procedimentos({ setIsLoggedIn }) {
  const navigate = useNavigate();

  // =================== ESTADO PARA VISUALIZAÇÃO DA DASHBAR ===================
  const [canSeeDashboard, setCanSeeDashboard] = useState(() => {
    const permissoes = JSON.parse(localStorage.getItem("permissoes") || "[]");
    return permissoes.includes("VIZUALIZAR_DASH");
  });

  /* ================ ESTADO DOS PROCEDIMENTOS ================ */
  const [procedimentos, setProcedimentos] = useState([]);
  const [busca, setBusca] = useState("");
  const [erroPermissao, setErroPermissao] = useState(null); 

  /* ================= MODAL NOVO PROCEDIMENTO ================= */
  const [openModalNovo, setOpenModalNovo] = useState(false);
  const [formNovoProcedimento, setFormNovoProcedimento] = useState({
    nome: "",
    valor: "", 
    duracao_minutos: "" 
  });
  
  /* ================= MODAL EDIÇÃO PROCEDIMENTO ================= */
  const [openModalEdicao, setOpenModalEdicao] = useState(false);
  const [procedimentoEmEdicao, setProcedimentoEmEdicao] = useState(null);

  /* ================ CARREGAR PROCEDIMENTOS DO BANCO  ================ */
  const carregarProcedimentos = async () => {
    setErroPermissao(null); 
    
    try {
      const token = localStorage.getItem("token");

      const response = await axios.get("http://localhost:3002/procedimentos", {
        headers: { Authorization: `Bearer ${token}` }
      });

      setProcedimentos(response.data.procedimentos);
    } catch (error) {
      console.error("Erro ao carregar procedimentos:", error);
      
      if (error.response && (error.response.status === 401 || error.response.status === 403)) {
        setErroPermissao("Você não tem permissão para visualizar esta página.");
        setProcedimentos([]);
      } else {
        setErroPermissao("Ocorreu um erro ao carregar os dados. Tente novamente.");
        setProcedimentos([]);
      }
    }
  }

  useEffect(() => {
    carregarProcedimentos();
  }, []);

  /* ================= FILTRO ================= */
  const procedimentosFiltrados = procedimentos.filter(p =>
    p.nome.toLowerCase().includes(busca.toLowerCase())
  );

  /* ================= HANDLERS NOVO PROCEDIMENTO  ================= */
  const handleChangeNovo = (e) => {
    const { name, value } = e.target;
    
    setFormNovoProcedimento(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSalvarNovo = async () => {
    try {
      const token = localStorage.getItem("token");
      
      const dadosParaEnviar = {
        nome: formNovoProcedimento.nome,
        valor: parseFloat(formNovoProcedimento.valor),
        duracao_minutos: parseInt(formNovoProcedimento.duracao_minutos, 10),
      };

      await axios.post("http://localhost:3002/procedimentos", dadosParaEnviar, {
        headers: { Authorization: `Bearer ${token}` }
      });

      alert("Procedimento cadastrado!");
      await carregarProcedimentos(); 

      setOpenModalNovo(false);
      setFormNovoProcedimento({ nome: "", valor: "", duracao_minutos: "" });

    } catch (error) {
      console.error(error);
      alert("Erro ao cadastrar procedimento.");
    }
  };

  /* ================= HANDLERS EDIÇÃO PROCEDIMENTO  ================= */
  const handleOpenEditModal = (procedimento) => {
    setProcedimentoEmEdicao({ 
      ...procedimento,
      valor: String(procedimento.valor),
      duracao_minutos: String(procedimento.duracao_minutos)
    });
    setOpenModalEdicao(true);
  };

  const handleCloseModalEdicao = () => {
    setOpenModalEdicao(false);
    setProcedimentoEmEdicao(null); 
  };

  const handleChangeEdicao = (e) => {
    const { name, value } = e.target;
    
    setProcedimentoEmEdicao(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSalvarEdicao = async () => {
    if (!procedimentoEmEdicao) return;
    
    try {
      const token = localStorage.getItem("token");

      const dadosParaEnviar = {
        nome: procedimentoEmEdicao.nome,
        valor: parseFloat(procedimentoEmEdicao.valor),
        duracao_minutos: parseInt(procedimentoEmEdicao.duracao_minutos, 10),
      };

      await axios.put(`http://localhost:3002/procedimentos/${procedimentoEmEdicao.id}`, dadosParaEnviar, {
        headers: { Authorization: `Bearer ${token}` }
      });

      alert("Procedimento atualizado com sucesso!");
      await carregarProcedimentos(); 
      handleCloseModalEdicao();

    } catch (error) {
      console.error("Erro ao atualizar procedimento:", error);
      alert("Erro ao atualizar procedimento.");
    }
  };

  /* ================= HANDLER EXCLUSÃO PROCEDIMENTO  ================= */
  const handleDelete = async (procedimentoId, nomeProcedimento) => {
    if (window.confirm(`Tem certeza que deseja excluir o procedimento ${nomeProcedimento}? Esta ação é irreversível.`)) {
      try {
        const token = localStorage.getItem("token");

        await axios.delete(`http://localhost:3002/procedimentos/${procedimentoId}`, {
          headers: { Authorization: `Bearer ${token}` }
        });

        alert(`Procedimento ${nomeProcedimento} excluído com sucesso.`);
        await carregarProcedimentos(); 

      } catch (error) {
        console.error("Erro ao excluir procedimento:", error);
        alert("Erro ao excluir procedimento.");
      }
    }
  };

  /* ================= LOGOUT  ================= */
  function handleLogout() {
    localStorage.removeItem("token");
    setIsLoggedIn(false);
    navigate("/");
  }

  return (
    <Box className="dashboard-layout">

      {/* ================= SIDEBAR  ================= */}
      <Box className="sidebar">
        <Box className="sidebar-logo">
          <Avatar
            sx={{
              width: 48,
              height: 48,
              backgroundColor: "#fff",
              color: "#5BA3C3",
              fontWeight: "bold"
            }}
          >
            M
          </Avatar>
        </Box>

        <Box className="sidebar-nav">
          {canSeeDashboard && (
            <IconButton className="nav-icon" onClick={() => navigate("/dashboard")}>
              <HomeIcon />
            </IconButton>
          )}

          <IconButton className="nav-icon" onClick={() => navigate("/agenda")}>
            <CalendarIcon />
          </IconButton>

          <IconButton className="nav-icon " onClick={() => navigate("/pacientes")}>
            <PeopleIcon />
          </IconButton>

          <IconButton className="nav-icon active" onClick={() => navigate("/procedimentos")}>
            <MedicineIcon />
          </IconButton>

          <IconButton className="nav-icon">
            <SettingsIcon />
          </IconButton>

          <div className="sidebar-logout">
            <IconButton className="nav-icon logout-btn" onClick={handleLogout}>
              <LogoutIcon />
            </IconButton>
          </div>
        </Box>
      </Box>

      {/* ================= CONTEÚDO PRINCIPAL  ================= */}
      <Box className="pacientes-container">
        <h1 className="titulo-pagina">GESTAO DE PROCEDIMENTOS</h1>
        
        {erroPermissao ? (
          <div style={{
            color: '#D32F2F', 
            backgroundColor: '#FFEBEE', 
            border: '1px solid #EF9A9A',
            padding: '20px', 
            borderRadius: '8px', 
            marginTop: '20px',
            textAlign: 'center',
            fontSize: '1.2rem',
            fontWeight: 'bold'
          }}>
            {erroPermissao}
          </div>
        ) : (
          <>
            <div className="linha-superior">
              <input
                className="input-busca"
                placeholder="Buscar procedimento"
                value={busca}
                onChange={(e) => setBusca(e.target.value)}
              />

              <button className="btn-novo" onClick={() => setOpenModalNovo(true)}>
                + NOVO PROCEDIMENTO
              </button>
            </div>

            <table className="tabela-pacientes">
              <thead>
                <tr>
                  <th>NOME</th>
                  <th>VALOR</th>
                  <th>DURAÇÃO</th>
                  <th>AÇÕES</th>
                </tr>
              </thead>

              <tbody>
                {procedimentosFiltrados.length === 0 && (
                  <tr>
                    <td colSpan="4" style={{ textAlign: "center" }}>Nenhum procedimento encontrado.</td>
                  </tr>
                )}

                {procedimentosFiltrados.map((p) => (
                  <tr key={p.id}>
                    <td>{p.nome}</td>
                    <td>{formatarPreco(p.valor)}</td> 
                    <td>{p.duracao_minutos} min</td>

                    <td className="acoes">
                      <Edit className="icon-acao" onClick={() => handleOpenEditModal(p)} />
                      <Delete className="icon-acao delete" onClick={() => handleDelete(p.id, p.nome)} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </>
        )}
      </Box>

      {/* ================= MODAL NOVO PROCEDIMENTO ================= */}
      <Modal open={openModalNovo} onClose={() => setOpenModalNovo(false)}>
        <Box
          sx={{
            position: "absolute",
            top: "50%", left: "50%",
            transform: "translate(-50%, -50%)",
            background: "#fff",
            borderRadius: "12px",
            padding: "30px",
            width: "420px",
            boxShadow: 5
          }}
        >
          <h2 style={{ marginBottom: "10px" }}>Novo Procedimento</h2>

          <TextField label="Nome" name="nome" fullWidth sx={{ mb: 2 }}
            value={formNovoProcedimento.nome} onChange={handleChangeNovo}
          />

          <TextField label="Preço Base (R$)" name="valor" type="number" fullWidth sx={{ mb: 2 }}
            value={formNovoProcedimento.valor} onChange={handleChangeNovo}
            inputProps={{ step: "0.01" }}
          />

          <TextField label="Duração (minutos)" name="duracao_minutos" type="number" fullWidth sx={{ mb: 3 }}
            value={formNovoProcedimento.duracao_minutos} onChange={handleChangeNovo}
          />

          <Button variant="contained" fullWidth sx={{ background: "#5BA3C3" }} onClick={handleSalvarNovo}>
            Salvar
          </Button>
        </Box>
      </Modal>

      {/* ================= MODAL EDIÇÃO PROCEDIMENTO  ================= */}
      {procedimentoEmEdicao && (
        <Modal open={openModalEdicao} onClose={handleCloseModalEdicao}>
          <Box
            sx={{
              position: "absolute",
              top: "50%", left: "50%",
              transform: "translate(-50%, -50%)",
              background: "#fff",
              borderRadius: "12px",
              padding: "30px",
              width: "420px",
              boxShadow: 5
            }}
          >
            <h2 style={{ marginBottom: "10px" }}>Editar Procedimento: {procedimentoEmEdicao.nome}</h2>

            <TextField label="Nome" name="nome" fullWidth sx={{ mb: 2 }}
              value={procedimentoEmEdicao.nome} onChange={handleChangeEdicao}
            />

            <TextField label="Preço Base (R$)" name="valor" type="number" fullWidth sx={{ mb: 2 }}
              value={procedimentoEmEdicao.valor} onChange={handleChangeEdicao}
              inputProps={{ step: "0.01" }}
            />

            <TextField label="Duração (minutos)" name="duracao_minutos" type="number" fullWidth sx={{ mb: 3 }}
              value={procedimentoEmEdicao.duracao_minutos} onChange={handleChangeEdicao}
            />

            <Button variant="contained" fullWidth sx={{ background: "#5BA3C3" }} onClick={handleSalvarEdicao}>
              Salvar Alterações
            </Button>
          </Box>
        </Modal>
      )}

    </Box>
  );
}
