import "../CSS/Dash.css";
import { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

import {
  Box,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Avatar,
  Typography,
  AppBar,
  Toolbar,
  IconButton,
  CircularProgress
} from "@mui/material";

import {
  Home as HomeIcon,
  EventNote as CalendarIcon,
  People as PeopleIcon,
  Vaccines as MedicineIcon,
  Settings as SettingsIcon,
  Logout as LogoutIcon
} from "@mui/icons-material";

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from "recharts";

/* ================= COMPONENTE ================= */

export default function Dashboard({ setIsLoggedIn }) {
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [erro, setErro] = useState(null);
  const [dados, setDados] = useState({
    totalPacientes: 0,
    totalAgendamentos: 0,
    procedimentosMes: 0,
    faturamentoMes: 0,
    proximasConsultas: [],
    agendamentosPorMes: []
  });

  function handleLogout() {
    localStorage.removeItem("token");
    setIsLoggedIn(false);
    navigate("/");
  }

 useEffect(() => {
  async function carregarDashboard() {
    try {
      const token = localStorage.getItem("token");
      const response = await axios.get("http://localhost:3002/dashboard", {
        headers: { Authorization: `Bearer ${token}` }
      });
      setDados(response.data);
      setLoading(false);
    } catch (error) {
      console.error("Erro ao carregar dashboard:", error);
      setErro("Não foi possível carregar os dados.");
      setLoading(false);
    }
  }

  carregarDashboard();
}, []);

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  if (erro) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <Typography variant="h5" color="error">{erro}</Typography>
      </Box>
    );
  }

  return (
    <Box className="dashboard-layout">

      {/* ================= SIDEBAR ================= */}
      <Box className="sidebar">
        <Box className="sidebar-logo">
          <Avatar
            sx={{
              width: 48,
              height: 48,
              backgroundColor: "#fff",
              color: "#5BA3C3",
              fontWeight: "bold"
            }}
          >
            M
          </Avatar>
        </Box>

        <Box className="sidebar-nav">

          <IconButton className="nav-icon active" onClick={() => navigate("/dashboard")}>
            <HomeIcon />
          </IconButton>

          <IconButton className="nav-icon" onClick={() => navigate("/agenda")}>
            <CalendarIcon />
          </IconButton>

          <IconButton className="nav-icon" onClick={() => navigate("/pacientes")}>
            <PeopleIcon />
          </IconButton>

          <IconButton className="nav-icon" onClick={() => navigate("/procedimentos")}>
            <MedicineIcon />
          </IconButton>

          <IconButton className="nav-icon">
            <SettingsIcon />
          </IconButton>

          <div className="sidebar-logout">
            <IconButton
              className="nav-icon logout-btn"
              onClick={handleLogout}
              title="Sair"
            >
              <LogoutIcon />
            </IconButton>
          </div>

        </Box>
      </Box>

      {/* ================= CONTEÚDO PRINCIPAL ================= */}
      <Box className="main-content">

        <AppBar
          position="static"
          color="transparent"
          elevation={0}
          className="dashboard-header"
        >
          <Toolbar>
            <Typography
              variant="h5"
              sx={{ flexGrow: 1, fontWeight: 800, color: "#1a202c" }}
            >
              Dashboard
            </Typography>
          </Toolbar>
        </AppBar>

        <Box className="cards-grid">
          <Paper className="stat-card">
            <Typography variant="subtitle2">Pacientes cadastrados</Typography>
            <Typography variant="h3" className="stat-value">{dados.totalPacientes}</Typography>
          </Paper>

          <Paper className="stat-card">
            <Typography variant="subtitle2">Total de Agendamentos</Typography>
            <Typography variant="h3" className="stat-value">{dados.totalAgendamentos}</Typography>
          </Paper>

          <Paper className="stat-card">
            <Typography variant="subtitle2">Procedimentos realizados mês</Typography>
            <Typography variant="h3" className="stat-value">{dados.procedimentosMes}</Typography>
          </Paper>

          <Paper className="stat-card">
            <Typography variant="subtitle2">Faturamento do mês</Typography>
            <Typography variant="h3" className="stat-value">
              R$ {Number(dados.faturamentoTotalDoMes).toFixed(2).replace(".", ",")}
            </Typography>
          </Paper>
        </Box>

        <Box className="content-grid">

          <Paper className="content-card">
            <Typography variant="h6" className="card-title">Próximas consultas</Typography>

            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell sx={{ fontWeight: "bold", color: "#718096" }}>
                      Paciente
                    </TableCell>
                    <TableCell align="right" sx={{ fontWeight: "bold", color: "#718096" }}>
                      Horário
                    </TableCell>
                  </TableRow>
                </TableHead>

                <TableBody>
                  {dados.proximasConsultas.map((row, index) => (
                    <TableRow key={index}>
                      <TableCell sx={{ py: 2 }}>{row.paciente}</TableCell>
                      <TableCell align="right" sx={{ py: 2 }}>
                        {new Date(row.data_hora).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>

              </Table>
            </TableContainer>
          </Paper>

          <Paper className="content-card">
            <Typography variant="h6" className="card-title">
              Agendamentos por mês
            </Typography>

            <Box sx={{ width: "100%", height: 280 }}>
              <ResponsiveContainer>
                <BarChart data={dados.agendamentosPorMes}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis dataKey="mes" axisLine={false} tickLine={false} dy={10} stroke="#718096" />
                  <YAxis axisLine={false} tickLine={false} stroke="#718096" />
                  <Tooltip cursor={{ fill: "transparent" }} />
                  <Bar
                    dataKey="total"
                    fill="#6caccf"
                    radius={[4, 4, 0, 0]}
                    barSize={60}
                  />
                </BarChart>
              </ResponsiveContainer>
            </Box>

          </Paper>

        </Box>

      </Box>

    </Box>
  );
}
