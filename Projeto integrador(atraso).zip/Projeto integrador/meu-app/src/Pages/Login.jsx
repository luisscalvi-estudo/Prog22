import { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "../CSS/Login.css";

export default function Login({ setIsLoggedIn, setCanSeeDashboard }) {
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [message, setMessage] = useState("");

  // Cadastro
  const [openRegister, setOpenRegister] = useState(false);
  const [regNome, setRegNome] = useState("");
  const [regEmail, setRegEmail] = useState("");
  const [regSenha, setRegSenha] = useState("");
  const [regMensagem, setRegMensagem] = useState("");

  const navigate = useNavigate();

  // ===================== LOGIN =====================
  async function enviaLogin(e) {
    e.preventDefault();
    setMessage("");

    try {
      // Faz login e recebe token
      const loginResponse = await axios.post("http://localhost:3002/login", {
        email,
        senha,
      });

      if (loginResponse.status === 200) {
        const token = loginResponse.data.token;
        localStorage.setItem("token", token);

        // Busca apenas as permissões do usuário logado
        const permResponse = await axios.get(
          `http://localhost:3002/usuario_permissao/usuario/${email}`,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );

        // CORREÇÃO: usar 'permissoes' e não 'usuarioPermissoes'
        const usuarioPermissoes = permResponse.data.permissoes || [];
        const permissoesUsuario = usuarioPermissoes.map(
          (u) => u.Permissao?.descricao
        );

        // Salva permissões no localStorage
        localStorage.setItem("permissoes", JSON.stringify(permissoesUsuario));

        // Atualiza estado global
        setIsLoggedIn(true);
        setCanSeeDashboard(permissoesUsuario.includes("VIZUALIZAR_DASH"));

        // Navega conforme permissão
        if (permissoesUsuario.includes("VIZUALIZAR_DASH")) {
          navigate("/dashboard");
        } else {
          navigate("/agenda");
        }
      }
    } catch (error) {
      console.error("Erro no login:", error);
      setMessage("Email ou senha inválidos!");
    }
  }

  // ===================== CADASTRO =====================
  async function enviarCadastro(e) {
    e.preventDefault();
    setRegMensagem("");

    console.log("Valores sendo enviados:", {
      nome: regNome,
      email: regEmail,
      senha: regSenha,
    });

    try {
      await axios.post("http://localhost:3002/novoUsuario", {
        nome: regNome,
        email: regEmail,
        senha: regSenha,
      });

      setRegMensagem("Usuário criado com sucesso!");
      setTimeout(() => setOpenRegister(false), 1200);
    } catch (err) {
      console.error(err);
      setRegMensagem("Erro ao criar usuário!");
    }
  }

  return (
    <>
      <div className="login-container">
        <div className="login-card">
          <h1>Log In</h1>

          <form onSubmit={enviaLogin}>
            <label>Email</label>
            <input
              type="email"
              placeholder="seu@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />

            <label>Senha</label>
            <div className="password-box">
              <input
                type={showPassword ? "text" : "password"}
                value={senha}
                onChange={(e) => setSenha(e.target.value)}
                required
              />
              <span
                className="eye"
                onClick={() => setShowPassword(!showPassword)}
              >
                👁
              </span>
            </div>

            <button type="submit" className="login-btn">
              LOGIN
            </button>

            <p className="register">
              Não possui uma conta?{" "}
              <span
                onClick={() => setOpenRegister(true)}
                className="register-link"
              >
                Cadastre-se
              </span>
            </p>

            {message && <p className="error">{message}</p>}
          </form>
        </div>
      </div>

      {/* MODAL DE CADASTRO */}
      {openRegister && (
        <div className="modal-overlay">
          <div className="modal-card-alt">
            <h2>Criar nova conta</h2>

            <form onSubmit={enviarCadastro}>
              <div className="input-group">
                <label>Nome</label>
                <input
                  type="text"
                  value={regNome}
                  onChange={(e) => setRegNome(e.target.value)}
                  required
                />
              </div>

              <div className="input-group">
                <label>Email</label>
                <input
                  type="email"
                  value={regEmail}
                  onChange={(e) => setRegEmail(e.target.value)}
                  required
                />
              </div>

              <div className="input-group">
                <label>Senha</label>
                <input
                  type="password"
                  value={regSenha}
                  onChange={(e) => setRegSenha(e.target.value)}
                  required
                />
              </div>

              <button type="submit" className="login-btn">
                Criar Conta
              </button>
              {regMensagem && <p className="success">{regMensagem}</p>}
            </form>

            <button
              className="close-modal"
              onClick={() => setOpenRegister(false)}
            >
              X
            </button>
          </div>
        </div>
      )}
    </>
  );
}
