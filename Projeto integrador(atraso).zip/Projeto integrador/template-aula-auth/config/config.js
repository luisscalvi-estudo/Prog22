// config/config.js (Este arquivo é usado APENAS pelo Sequelize CLI)

module.exports = {
  // O ambiente que o CLI usará por padrão (ou via variável de ambiente)
  "development": { 
    "username": "postgres",
    "password": "POSTGRES",
    "database": "Odonto2",
    "host": "localhost",
    "port": 5432,
    "dialect": "postgres"
    // Não inclua o "schema" aqui, pois ele pode ser um problema nas migrations
  },
  "test": {
    // ...
  },
  "production": {
    // ...
  }
};