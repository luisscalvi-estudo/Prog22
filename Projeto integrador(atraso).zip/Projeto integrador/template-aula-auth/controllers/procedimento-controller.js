const express = require("express");
const procedimentoService = require("../services/procedimento-service");
const authService = require("../services/auth-service");

const router = express.Router();

// ==================== ROTAS DE PROCEDIMENTO ====================

// Aplica autenticação JWT em todas as rotas deste router
router.use(authService.requireJWTAuth);

// GET /procedimentos - retorna todos os procedimentos
router.get("/", procedimentoService.retornaTodos);

// GET /procedimentos/:id - retorna procedimento por ID
router.get("/:id", procedimentoService.retornaPorId);

// POST /procedimentos - cria novo procedimento
router.post("/", procedimentoService.cria);

// PUT /procedimentos/:id - atualiza procedimento existente
router.put("/:id", procedimentoService.atualiza);

// DELETE /procedimentos/:id - deleta procedimento
router.delete("/:id", procedimentoService.deleta);

module.exports = router;
