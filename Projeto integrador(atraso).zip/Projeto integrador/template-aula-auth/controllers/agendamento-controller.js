const express = require("express");
const agendamentoService = require("../services/agendamento-service");
const authService = require("../services/auth-service");

const router = express.Router();

// ==================== ROTAS DE AGENDAMENTO ====================

// Middleware de autenticação JWT aplicado a todas as rotas
router.use(authService.requireJWTAuth);

// GET /agendamentos - retorna todos os agendamentos
router.get("/", agendamentoService.retornaTodos);

// GET /agendamentos/:id - retorna um agendamento por ID
router.get("/:id", agendamentoService.retornaPorId);

// POST /agendamentos - cria um novo agendamento
router.post("/", agendamentoService.cria);

// PUT /agendamentos/:id - atualiza um agendamento existente
router.put("/:id", agendamentoService.atualiza);

// DELETE /agendamentos/:id - deleta um agendamento
router.delete("/:id", agendamentoService.deleta);

module.exports = router;
