const express = require("express");
const authService = require("../services/auth-service");
const usuarioService = require("../services/usuario-service");

const router = express.Router();

// ==================== ROTAS DE USUÁRIO ====================

// Aplica autenticação JWT em todas as rotas deste router
router.use(authService.requireJWTAuth);

// POST /usuario - criar novo usuário
router.post("/", usuarioService.criaUsuario);

// GET /usuario/todos - retornar todos os usuários
router.get("/todos", usuarioService.retornaTodosUsuarios);

// GET /usuario/:id - retornar usuário por ID
router.get("/:id", usuarioService.retornaUsuarioPorId);

// GET /usuario/:id/permissoes - retornar usuário com permissões
router.get("/:id/permissoes", usuarioService.retornaUsuarioComPermissoes);

// PUT /usuario/:id - atualizar usuário existente
router.put("/:id", usuarioService.atualizaUsuario);

// DELETE /usuario/:id - deletar usuário
router.delete("/:id", usuarioService.deletaUsuario);

module.exports = router;
