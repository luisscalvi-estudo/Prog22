const express = require("express");
const authService = require("../services/auth-service");
const usuarioPermissaoService = require("../services/usuario_permissao-service");

const router = express.Router();

// ==================== ROTAS USUÁRIO-PERMISSÃO ====================

// Aplica autenticação JWT em todas as rotas deste router
router.use(authService.requireJWTAuth);

// POST /usuario_permissao - criar nova associação usuário-permissão
router.post("/", usuarioPermissaoService.criaUsuarioPermissao);

// GET /usuario_permissao/todos - retornar todas as associações usuário-permissão
router.get("/todos", usuarioPermissaoService.retornaTodosUsuarioPermissoes);

// GET /usuario_permissao/usuario/:email - retornar todas as permissões de um usuário
router.get("/usuario/:email", usuarioPermissaoService.retornaPermissoesPorUsuario);

// GET /usuario_permissao/permissao/:id_permissao - retornar todos os usuários com uma permissão
router.get("/permissao/:id_permissao", usuarioPermissaoService.retornaUsuariosPorPermissao);

// GET /usuario_permissao/verificar/:email/:id_permissao - verificar se usuário tem permissão
router.get(
  "/verificar/:email/:id_permissao",
  usuarioPermissaoService.verificaPermissaoUsuario
);

// DELETE /usuario_permissao/:email/:id_permissao - deletar associação usuário-permissão
router.delete("/:email/:id_permissao", usuarioPermissaoService.deletaUsuarioPermissao);

module.exports = router;
