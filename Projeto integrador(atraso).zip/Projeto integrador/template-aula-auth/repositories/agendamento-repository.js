const model = require("../models");
const { DateTime } = require("luxon");

// ==== FUNÇÃO AUXILIAR: AJUSTAR HORÁRIO PARA O FRONT ====
// Converte data UTC do banco → horário local (São Paulo)
function ajustarParaHorarioLocal(ag) {
    if (!ag || !ag.data_hora) return ag;

    const local = DateTime
        .fromJSDate(ag.data_hora, { zone: "utc" })   // interpreta como UTC
        .setZone("America/Sao_Paulo");               // converte para horário BR

    ag.data_hora = local.toISO(); // retorna ISO string para o Front

    return ag;
}

/* ================= LISTAR ================= */
// Retorna todos os agendamentos, aplicando filtro opcional
const obterTodos = async (filtro = {}) => {
    const lista = await model.Agendamento.findAll({
        where: filtro,
        include: [
            { model: model.Paciente },                       // inclui paciente
            { model: model.Procedimento },                  // inclui procedimento
            { model: model.Usuario, attributes: ["id", "nome"] } // inclui usuário (apenas id/nome)
        ],
        order: [["data_hora", "ASC"]], // ordena por data/hora
    });

    // Ajusta horários para o front
    return lista.map(ag => ajustarParaHorarioLocal(ag));
};

/* ================= BUSCAR POR ID ================= */
// Retorna um agendamento específico pelo ID
const obterPorId = async ({ id }) => {
    const ag = await model.Agendamento.findByPk(id, {
        include: [
            model.Paciente,
            model.Procedimento,
            { model: model.Usuario, attributes: ["id", "nome"] }
        ],
    });

    return ajustarParaHorarioLocal(ag);
};

/* ================= CRIAR ================= */
// Cria um novo agendamento no banco
const criar = async (ag) => {
    const novo = await model.Agendamento.create(ag);
    return ajustarParaHorarioLocal(novo);
};

/* ================= ATUALIZAR ================= */
// Atualiza um agendamento existente
const atualizar = async (ag) => {
    await model.Agendamento.update(ag, { where: { id: ag.id } });

    // Retorna registro atualizado com dados completos
    const atualizado = await model.Agendamento.findByPk(ag.id, {
        include: [
            model.Paciente,
            model.Procedimento,
            { model: model.Usuario, attributes: ["id", "nome"] }
        ]
    });

    return ajustarParaHorarioLocal(atualizado);
};

/* ================= DELETAR ================= */
// Deleta um agendamento pelo ID
const deletar = async (ag) => {
    await model.Agendamento.destroy({ where: { id: ag.id } });
    return ag; // retorna objeto deletado (não do DB)
};

module.exports = {
    obterTodos,
    obterPorId,
    criar,
    atualizar,
    deletar,
};
