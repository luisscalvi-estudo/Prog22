const model = require("../models");

const obterTodos = async () => {
	return await model.Procedimento.findAll();
};

const obterPorId = async (procedimento) => {
	return await model.Procedimento.findByPk(procedimento.id);
};

const criar = async (procedimento) => {
	return await model.Procedimento.create(procedimento);
};

const atualizar = async (procedimento) => {
	await model.Procedimento.update(procedimento, {
		where: { id: procedimento.id },
	});
	return await model.Procedimento.findByPk(procedimento.id);
};

const deletar = async (procedimento) => {
	await model.Procedimento.destroy({ where: { id: procedimento.id } });
	return procedimento;
};

module.exports = {
	obterTodos,
	obterPorId,
	criar,
	atualizar,
	deletar,
};
