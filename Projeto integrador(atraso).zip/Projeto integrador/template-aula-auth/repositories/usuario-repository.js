const model = require("../models");

// ==================== LISTAR ====================
// Retorna todos os usuários
const obterTodosUsuarios = async () => {
    return await model.Usuario.findAll();
};

// ==================== BUSCAR POR ID ====================
// Retorna um usuário pelo ID
const obterUsuarioPorId = async ({ id }) => {
    return await model.Usuario.findByPk(id);
};

// ==================== BUSCAR POR ID + PERMISSÕES ====================
// Retorna usuário com suas permissões (se existirem)
const obterUsuarioComPermissoes = async ({ id }) => {
    return await model.Usuario.findByPk(id, {
        include: [model.Permissao] // join com permissões
    });
};

// ==================== CRIAR ====================
// Cria um novo usuário
const criarUsuario = async (usuario) => {
    return await model.Usuario.create(usuario);
};

// ==================== ATUALIZAR ====================
// Atualiza campos específicos de um usuário
const atualizarUsuario = async ({ id, nome, senha, eh_dentista }) => {
    const dados = {};

    if (nome) dados.nome = nome;
    if (senha) dados.senha = senha;
    if (eh_dentista !== undefined) dados.eh_dentista = eh_dentista;

    await model.Usuario.update(dados, { where: { id } });

    // Retorna o usuário atualizado
    return await model.Usuario.findByPk(id);
};

// ==================== DELETAR ====================
// Deleta usuário pelo ID
const deletarUsuario = async ({ id }) => {
    const usuario = await model.Usuario.findByPk(id);

    if (!usuario) return null;

    await model.Usuario.destroy({ where: { id } });

    return usuario; // retorna objeto deletado
};

module.exports = {
    obterTodosUsuarios,
    obterUsuarioPorId,
    obterUsuarioComPermissoes,
    criarUsuario,
    atualizarUsuario,
    deletarUsuario
};
