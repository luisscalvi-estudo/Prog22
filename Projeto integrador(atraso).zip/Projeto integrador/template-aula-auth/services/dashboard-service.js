const db = require("../models");
const { QueryTypes } = require("sequelize");

// ======================================================
// SERVICE DO DASHBOARD
// ======================================================
module.exports = {
  // ==================== RESUMO DO DASHBOARD ====================
  async getDashboardInfo() {
    try {
      // Total de pacientes e agendamentos
      const totalPacientes = await db.Paciente.count();
      const totalAgendamentos = await db.Agendamento.count();

      // -----------------------------
      // AGENDAMENTOS POR MÊS
      // -----------------------------
      const agendamentosPorMes = await db.sequelize.query(
        `
        SELECT 
          TO_CHAR(data_hora, 'YYYY-MM') AS mes,
          COUNT(*) AS total
        FROM agendamentos
        GROUP BY mes
        ORDER BY mes;
        `,
        { type: QueryTypes.SELECT }
      );

      // -----------------------------
      // PRÓXIMAS CONSULTAS
      // -----------------------------
      const proximasConsultas = await db.sequelize.query(
        `
        SELECT 
          a.data_hora,
          p.nome AS paciente
        FROM agendamentos a
        JOIN pacientes p ON p.id = a.paciente_id
        WHERE a.data_hora >= NOW()
        ORDER BY a.data_hora
        LIMIT 5;
        `,
        { type: QueryTypes.SELECT }
      );

      // -----------------------------
      // PROCEDIMENTOS REALIZADOS NO MÊS
      // -----------------------------
      const procedimentosMes = await db.sequelize.query(
        `
        SELECT COUNT(*) AS total
        FROM agendamentos
        WHERE TO_CHAR(data_hora, 'YYYY-MM') = TO_CHAR(NOW(), 'YYYY-MM');
        `,
        { type: QueryTypes.SELECT }
      );

      // -----------------------------
      // FATURAMENTO DO MÊS
      // -----------------------------
      const faturamentoMes = await db.sequelize.query(
        `
        SELECT
          SUM(p.valor) AS faturamento_total_do_mes
        FROM agendamentos a
        JOIN procedimentos p ON a.procedimento_id = p.id
        WHERE a.data_hora >= date_trunc('month', CURRENT_DATE)
          AND a.data_hora < (date_trunc('month', CURRENT_DATE) + interval '1 month')
          AND a.status IN ('concluido', 'pago');
        `,
        { type: QueryTypes.SELECT }
      );

      // ==================== RETORNO ====================
      return {
        totalPacientes,
        totalAgendamentos,
        agendamentosPorMes,
        proximasConsultas,
        procedimentosMes: procedimentosMes[0].total,
        faturamentoTotalDoMes: faturamentoMes[0].faturamento_total_do_mes,
      };
    } catch (error) {
      console.error("Erro no DashboardService:", error);
      throw error;
    }
  },
};
