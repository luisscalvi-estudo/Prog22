const procRepo = require("../repositories/procedimento-repository");

// ==================== LISTAR TODOS ====================
const retornaTodos = async (req, res) => {
    try {
        const lista = await procRepo.obterTodos();
        res.status(200).json({ procedimentos: lista });
    } catch (error) {
        console.error("Erro ao buscar procedimentos:", error);
        res.sendStatus(500);
    }
};

// ==================== BUSCAR POR ID ====================
const retornaPorId = async (req, res) => {
    try {
        const id = parseInt(req.params.id);
        const item = await procRepo.obterPorId({ id });

        if (!item) {
            return res.status(404).json({ message: "Procedimento não encontrado." });
        }

        res.status(200).json(item);
    } catch (error) {
        console.error(error);
        res.sendStatus(500);
    }
};

// ==================== CRIAR ====================
const cria = async (req, res) => {
    try {
        const { nome, valor, duracao_minutos } = req.body;

        if (!nome || !valor) {
            return res.status(400).json({ message: "Nome e valor são obrigatórios." });
        }

        const novo = await procRepo.criar({ nome, valor, duracao_minutos });
        res.status(201).json(novo);
    } catch (error) {
        console.error(error);
        res.sendStatus(500);
    }
};

// ==================== ATUALIZAR ====================
const atualiza = async (req, res) => {
    try {
        const id = parseInt(req.params.id);
        const { nome, valor, duracao_minutos } = req.body;

        const atualizado = await procRepo.atualizar({ id, nome, valor, duracao_minutos });
        res.status(200).json(atualizado);
    } catch (error) {
        console.error(error);
        res.sendStatus(500);
    }
};

// ==================== DELETAR ====================
const deleta = async (req, res) => {
    try {
        const id = parseInt(req.params.id);
        await procRepo.deletar({ id });
        res.status(200).json({ message: "Procedimento removido." });
    } catch (error) {
        console.error(error);
        res.sendStatus(500);
    }
};

module.exports = { retornaTodos, retornaPorId, cria, atualiza, deleta };
