// =========================
//         IMPORTS
// =========================
const express = require("express");
const cors = require("cors");
const session = require("express-session");
const passport = require("passport");
const dotenv = require("dotenv");

dotenv.config();

// Controllers
const usuarioPermissaoRouter = require("./controllers/usuario_permissao-controller");
const usuarioRouter = require("./controllers/usuario-controller");
const permissaoRouter = require("./controllers/permissao-controller");
const authRouter = require("./controllers/auth-controller");
const pacienteController = require("./controllers/paciente-controller");
const procedimentoController = require("./controllers/procedimento-controller");
const agendamentoController = require("./controllers/agendamento-controller");
const dashboardController = require("./controllers/dashboard-controller");

// Auth strategies
const authService = require("./services/auth-service");

// =========================
//      CONFIGURAÇÕES
// =========================
const app = express();
app.use(cors());
app.use(express.json());

// =========================
// 1️⃣ SESSIONS (ANTES DO PASSPORT)
// =========================
app.use(
    session({
        secret: process.env.SECRET_KEY || "alguma_frase_muito_doida_pra_servir_de_SECRET",
        resave: false,
        saveUninitialized: false,
        cookie: { secure: false }, // true apenas com HTTPS
    })
);

// =========================
// 2️⃣ INITIALIZE PASSPORT
// =========================
app.use(passport.initialize());
app.use(passport.session());

// =========================
// 3️⃣ CONFIGURAR ESTRATÉGIAS
// =========================
authService.configureLocalStrategy();
authService.configureJwtStrategy();
authService.configureSerialization();

// =========================
// 4️⃣ ROTAS
// =========================
app.use("/", authRouter);
app.use("/usuario_permissao", usuarioPermissaoRouter);
app.use("/usuario", usuarioRouter);
app.use("/permissao", permissaoRouter);
app.use("/pacientes", pacienteController);
app.use("/procedimentos", procedimentoController);
app.use("/agendamentos", agendamentoController);
app.use("/dashboard", dashboardController);

// =========================
//       INICIAR SERVIDOR
// =========================
const PORT = process.env.PORT || 3002;
app.listen(PORT, () => {
    console.log(`Servidor está rodando na porta ${PORT}.`);
});
